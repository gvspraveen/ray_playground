# Fwd: Dare to Be Wrong

![](https://readwise-assets.s3.amazonaws.com/static/images/article0.00998d930354.png)

### Metadata

- Author: instapaper.com
- Full Title: Fwd: Dare to Be Wrong
- Category: #articles


- URL: https://instapaper.com/read/1367610958

### Highlights

- Successful investing requires the ability to look wrong for a while and survive some mistakes ([View Highlight](https://instapaper.com/read/1367610958/14785765))
    - **Tags:** #finance
