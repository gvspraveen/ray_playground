# Fwd: Hip to Be Square

![](https://readwise-assets.s3.amazonaws.com/static/images/article2.74d541386bbf.png)

### Metadata

- Author: instapaper.com
- Full Title: Fwd: Hip to Be Square
- Category: #articles


- URL: https://instapaper.com/read/1371171484

### Highlights

- All of these new offerings are ways of bringing money into the ecosystem. When money comes into the ecosystem, customers transact more. When customers transact more, we make more revenue, and there’s a very direct correlation between those two things. ([View Highlight](https://instapaper.com/read/1371171484/14906212))
    - **Tags:** #favorite
- Square has done an unbelievable job of Square Cash. So you’ve had a huge amount of value in what you and I would have called the financial system, which has moved out of the banking system… I look at some of those things very often to say, ‘We could have done that, too,’ and we didn’t ([View Highlight](https://instapaper.com/read/1371171484/14906234))
