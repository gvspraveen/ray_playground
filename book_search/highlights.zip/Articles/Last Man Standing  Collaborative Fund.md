# Last Man Standing · Collaborative Fund

![](https://readwise-assets.s3.amazonaws.com/static/images/article0.00998d930354.png)

### Metadata

- Author: collaborativefund.com
- Full Title: Last Man Standing · Collaborative Fund
- Category: #articles


- URL: http://www.collaborativefund.com/blog/standing/

### Highlights

- Likewise, investors’ goals shouldn’t be the best annual returns. It should be to maximize wealth. And you get that through endurance – not to be the best in any given year, but to be the last man standing. ([View Highlight](https://instapaper.com/read/1371411058/14913754))
    - **Tags:** #finance, #favorite
