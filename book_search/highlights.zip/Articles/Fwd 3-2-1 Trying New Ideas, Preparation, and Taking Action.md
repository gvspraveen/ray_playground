# Fwd: 3-2-1: Trying New Ideas, Preparation, and Taking Action

![](https://readwise-assets.s3.amazonaws.com/static/images/article3.5c705a01b476.png)

### Metadata

- Author: instapaper.com
- Full Title: Fwd: 3-2-1: Trying New Ideas, Preparation, and Taking Action
- Category: #articles


- URL: https://instapaper.com/read/1454276284

### Highlights

- “Nearly everything in life is unfavorable once it grows to a certain size.
  It is entirely possible to have too many clients, too much work, too much fame, too much free time, and so on.
  Pay attention to when the thing you’re chasing exceeds its usefulness.” ([View Highlight](https://instapaper.com/read/1454276284/17784125))
