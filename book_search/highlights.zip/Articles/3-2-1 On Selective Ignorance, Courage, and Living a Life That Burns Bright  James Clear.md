# 3-2-1: On Selective Ignorance, Courage, and Living a Life That Burns Bright | James Clear

![](https://readwise-assets.s3.amazonaws.com/static/images/article3.5c705a01b476.png)

### Metadata

- Author: jamesclear.com
- Full Title: 3-2-1: On Selective Ignorance, Courage, and Living a Life That Burns Bright | James Clear
- Category: #articles


- URL: https://jamesclear.com/3-2-1/october-29-2020

### Highlights

- “The math of success…
  Results = (Hard Work*Time)^Strategy
  Working hard is important, but working on the right thing is more important. A great strategy can deliver exponential results.
  Of course, the best strategy is worth nothing if you never get to work. Zero to the millionth power is still zero.” ([View Highlight](https://instapaper.com/read/1356526454/14429407))
    - **Tags:** #habits, #favorite
