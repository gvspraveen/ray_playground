# Save Like a Pessimist, Invest Like an Optimist · Collaborative Fund

![](https://readwise-assets.s3.amazonaws.com/static/images/article3.5c705a01b476.png)

### Metadata

- Author: collaborativefund.com
- Full Title: Save Like a Pessimist, Invest Like an Optimist · Collaborative Fund
- Category: #articles


- URL: http://www.collaborativefund.com/blog/save-like-a-pessimist-invest-like-an-optimist/

### Highlights

- Save like a pessimist, investing like an optimist. ([View Highlight](https://instapaper.com/read/1363924513/14659196))
    - **Tags:** #finance
