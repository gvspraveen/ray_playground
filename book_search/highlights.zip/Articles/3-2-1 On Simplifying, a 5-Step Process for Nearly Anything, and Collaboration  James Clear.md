# 3-2-1: On Simplifying, a 5-Step Process for Nearly Anything, and Collaboration | James Clear

![](https://readwise-assets.s3.amazonaws.com/static/images/article0.00998d930354.png)

### Metadata

- Author: jamesclear.com
- Full Title: 3-2-1: On Simplifying, a 5-Step Process for Nearly Anything, and Collaboration | James Clear
- Category: #articles


- URL: https://jamesclear.com/3-2-1/october-22-2020

### Highlights

- “To simplify before you understand the details is ignorance.
  To simplify after you understand the details is genius ([View Highlight](https://instapaper.com/read/1354680871/14368203))
    - **Tags:** #favorite
