# Fwd: 3-2-1: A Quick Tip for Building Habits That Last, and the Connection Between Art and an Open Mind

![](https://readwise-assets.s3.amazonaws.com/static/images/article4.6bc1851654a0.png)

### Metadata

- Author: instapaper.com
- Full Title: Fwd: 3-2-1: A Quick Tip for Building Habits That Last, and the Connection Between Art and an Open Mind
- Category: #articles


- URL: https://instapaper.com/read/1434185693

### Highlights

- “A quick and easy tip for building habits that last:
  Pick a standard time and place to do it.
  It’s easier to wake up knowing “I exercise at 4pm” than to decide each time when to fit a habit into your day.
  If it’s already decided, all you need to do is show up.” ([View Highlight](https://instapaper.com/read/1434185693/17116431))
    - **Tags:** #habits
