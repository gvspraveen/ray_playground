# Fwd: Google Earnings, Google’s Response to ATT, Google Cloud Losses

![](https://readwise-assets.s3.amazonaws.com/static/images/article1.be68295a7e40.png)

### Metadata

- Author: instapaper.com
- Full Title: Fwd: Google Earnings, Google’s Response to ATT, Google Cloud Losses
- Category: #articles


- URL: https://instapaper.com/read/1385551295

### Highlights

- Monopolists lie to protect themselves. They know that bragging about their great monopoly invites being audited, scrutinized, and attacked. Since they very much want their monopoly profits to continue unmolested, they tend to do whatever they can to conceal their monopoly — usually by exaggerating the power of their (nonexistent) competition. ([View Highlight](https://instapaper.com/read/1385551295/15449059))
