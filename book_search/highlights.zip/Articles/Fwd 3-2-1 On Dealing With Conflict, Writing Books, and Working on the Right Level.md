# Fwd: 3-2-1: On Dealing With Conflict, Writing Books, and Working on the Right Level

![](https://readwise-assets.s3.amazonaws.com/static/images/article1.be68295a7e40.png)

### Metadata

- Author: instapaper.com
- Full Title: Fwd: 3-2-1: On Dealing With Conflict, Writing Books, and Working on the Right Level
- Category: #articles


- URL: https://instapaper.com/read/1415551900

### Highlights

- But you likely realize your life will not be destroyed if your book doesn’t sell or if a potential date turns you down or if your startup goes bust. It’s not the failed outcome that paralyzes us. It’s the possibility of looking stupid, feeling humiliated, or dealing with embarrassment that prevents us from getting started at all. ([View Highlight](https://instapaper.com/read/1415551900/16512149))
