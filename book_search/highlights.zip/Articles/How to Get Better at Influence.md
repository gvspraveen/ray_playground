# How to Get Better at Influence

![](https://readwise-assets.s3.amazonaws.com/static/images/article4.6bc1851654a0.png)

### Metadata

- Author: Lenny's Newsletter
- Full Title: How to Get Better at Influence
- Category: #articles

### Highlights

- ![](https://substackcdn.com/image/fetch/w_2912,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fbucketeer-e05bbc84-baa3-437e-9518-adb32be77984.s3.amazonaws.com%2Fpublic%2Fimages%2F878661f2-8aa0-4b19-8a03-5d25b7dee9ac_3436x1938.png) ([View Highlight](https://read.readwise.io/read/01gdea3mhw6qfkvtbdbqhay6zv))
    - **Tags:** #leadership
