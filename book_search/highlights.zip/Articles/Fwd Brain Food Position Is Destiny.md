# Fwd: Brain Food: Position Is Destiny

![](https://readwise-assets.s3.amazonaws.com/static/images/article4.6bc1851654a0.png)

### Metadata

- Author: instapaper.com
- Full Title: Fwd: Brain Food: Position Is Destiny
- Category: #articles


- URL: https://instapaper.com/read/1517068072

### Highlights

- You can’t predict what will happen tomorrow, but you can improve your position by sleeping, eating healthy, and working out. You can’t predict what the stock market will do tomorrow, but you can improve your position by ensuring you are never a forced seller. You can’t predict what will happen in your job or life, but you can improve your position by always having a little bit of money on the side. You can’t predict if you will get a promotion, but you can put yourself in a position to get it by acquiring the skills you need before it becomes available.
  Good positioning lets you control your circumstances. Poor positioning lets your circumstances control you. ([View Highlight](https://instapaper.com/read/1517068072/19907365))
    - **Tags:** #compounding, #progress, #favorite
