# Fwd: Brain Food: Avoiding Bad Decisions, Ordinary Words, and Starting Today

![](https://readwise-assets.s3.amazonaws.com/static/images/article1.be68295a7e40.png)

### Metadata

- Author: instapaper.com
- Full Title: Fwd: Brain Food: Avoiding Bad Decisions, Ordinary Words, and Starting Today
- Category: #articles


- URL: https://instapaper.com/read/1395187449

### Highlights

- “I try to write using ordinary words and simple sentences. That kind of writing is easier to read, and the easier something is to read, the more deeply readers will engage with it. The less energy they expend on your prose, the more they’ll have left for your ideas.” ([View Highlight](https://instapaper.com/read/1395187449/15804748))
    - **Tags:** #writing
