# Fwd: Stagnationism

![](https://readwise-assets.s3.amazonaws.com/static/images/article2.74d541386bbf.png)

### Metadata

- Author: instapaper.com
- Full Title: Fwd: Stagnationism
- Category: #articles


- URL: https://instapaper.com/read/1371475232

### Highlights

- This slow-rolling of vaccine approval is a) incredible on its own, and b) strong evidence that the Great Stagnation is not over. Technological progress is dependent on many things simultaneously going right, but one of them is still going very, very wrong. Even a situation of maximum urgency, comparable to wartime, hasn’t altered key institutions’ behavior all that much. ([View Highlight](https://instapaper.com/read/1371475232/14917016))
    - **Tags:** #favorite
