# Fwd: Brain Food No. 398

![](https://readwise-assets.s3.amazonaws.com/static/images/article4.6bc1851654a0.png)

### Metadata

- Author: instapaper.com
- Full Title: Fwd: Brain Food No. 398
- Category: #articles


- URL: https://instapaper.com/read/1367756444

### Highlights

- A great leader’s first reaction is, hmm, say more. Tell me more. … Because it has this super big knock-on effect. One, it causes your subordinates to all think that if you’ve got an interesting thought, I’m open to hearing it. I’m not going to just shut that down because it disagrees with me. Everybody is more inclined to think about things and think about things differently, and not be afraid of that ([View Highlight](https://instapaper.com/read/1367756444/14793815))
    - **Tags:** #leadership
