# Fwd: Twitter Acquires Revue, Twitter’s Opportunity, Twitter’s Achilles Heel

![](https://readwise-assets.s3.amazonaws.com/static/images/article1.be68295a7e40.png)

### Metadata

- Author: instapaper.com
- Full Title: Fwd: Twitter Acquires Revue, Twitter’s Opportunity, Twitter’s Achilles Heel
- Category: #articles


- URL: https://instapaper.com/read/1381673517

### Highlights

- “The battle between every startup and incumbent comes down to whether the startup gets distribution before the incumbent gets innovation.” ([View Highlight](https://instapaper.com/read/1381673517/15311502))
    - **Tags:** #strategy, #favorite
