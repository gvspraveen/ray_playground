# Fwd: 3-2-1: On Lucky Events, Saying Thank You, and the Importance of Being Kind

![](https://readwise-assets.s3.amazonaws.com/static/images/article1.be68295a7e40.png)

### Metadata

- Author: instapaper.com
- Full Title: Fwd: 3-2-1: On Lucky Events, Saying Thank You, and the Importance of Being Kind
- Category: #articles


- URL: https://instapaper.com/read/1461401846

### Highlights

- “Most lucky events in life are opportunities, not outcomes.
  The value of an opportunity changes depending on how it is treated. Without effort, good luck becomes a missed opportunity. With effort, good luck can become a life-changing event.
  You need luck and hard work. It’s not either/or. It’s both/and. The result will not walk through the door on its own.‬‬‬‬‬‬‬‬‬” ([View Highlight](https://instapaper.com/read/1461401846/18027052))
