# Fwd: 3-2-1: On Copying Best Practices, Being Underestimated, and the Difficulty of Change

![](https://readwise-assets.s3.amazonaws.com/static/images/article2.74d541386bbf.png)

### Metadata

- Author: instapaper.com
- Full Title: Fwd: 3-2-1: On Copying Best Practices, Being Underestimated, and the Difficulty of Change
- Category: #articles


- URL: https://instapaper.com/read/1386570879

### Highlights

- “A brief guide to improvement:
  1) Lots of research. Explore widely and see what is possible.
  2) Lots of iterations. Focus on one thing, but do it in different ways. Refine your method.
  3) Lots of repetitions. Stick with your method until it stops working.
  Research. Iterate. Repeat.” ([View Highlight](https://instapaper.com/read/1386570879/15484296))
    - **Tags:** #progress
