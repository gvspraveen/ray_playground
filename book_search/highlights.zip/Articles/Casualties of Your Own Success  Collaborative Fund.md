# Casualties of Your Own Success · Collaborative Fund

![](https://readwise-assets.s3.amazonaws.com/static/images/article2.74d541386bbf.png)

### Metadata

- Author: collaborativefund.com
- Full Title: Casualties of Your Own Success · Collaborative Fund
- Category: #articles


- URL: http://www.collaborativefund.com/blog/casualties-of-your-own-success/

### Highlights

- success is associated with hubris, and hubris is the beginning of the end of success. Some of the most enduring animals aren’t apex predators, but they’re very good at evasion, camouflage, and armour. They’re paranoid. I always come back to the time Charlie Rose asked Michael Moritz how Sequoia Capital has thrived for three decades, and he said, “We’ve always been afraid of going out of business.” Paranoia in the face of success is extremely hard but in hindsight it’s the closest thing to a secret weapon that exists. ([View Highlight](https://instapaper.com/read/1408574472/16252057))
    - **Tags:** #favorite
