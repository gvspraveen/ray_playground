# Fwd: Colossus Weekly: Investing in Overlooked Businesses

![](https://readwise-assets.s3.amazonaws.com/static/images/article2.74d541386bbf.png)

### Metadata

- Author: instapaper.com
- Full Title: Fwd: Colossus Weekly: Investing in Overlooked Businesses
- Category: #articles


- URL: https://instapaper.com/read/1375069553

### Highlights

- There is a shifting relationship between the largest software companies in the world and their suppliers, and as the leading software companies have become ever-larger portions of the compute pie, it’s kind of become the problem of the tech companies, and not the semiconductor companies that service them to push forward the natural limits of hardware. Software ate the world so completely that now the large tech companies have to deal with the actual hardware that underlies their stack ([View Highlight](https://instapaper.com/read/1375069553/15060175))
    - **Tags:** #strategy
