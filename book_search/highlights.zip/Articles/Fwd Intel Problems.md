# Fwd: Intel Problems

![](https://readwise-assets.s3.amazonaws.com/static/images/article2.74d541386bbf.png)

### Metadata

- Author: instapaper.com
- Full Title: Fwd: Intel Problems
- Category: #articles


- URL: https://instapaper.com/read/1379779952

### Highlights

- In short, Intel is losing share in PCs, even as it is threatened by AMD for x86 servers in the datacenter, and even as cloud companies like Amazon integrated backwards into the processor; I haven’t even touched on the increase in other specialized datacenter operations like GPU-based applications for machine learning, which are designed by companies like Nvidia and manufactured by — you guessed it! — TSMC.
