# Now You Get It · Collaborative Fund

![](https://readwise-assets.s3.amazonaws.com/static/images/article2.74d541386bbf.png)

### Metadata

- Author: collaborativefund.com
- Full Title: Now You Get It · Collaborative Fund
- Category: #articles


- URL: http://www.collaborativefund.com/blog/experience/

### Highlights

- I think part is the same reason predicting loss is difficult: It’s hard to imagine the full context. If you think of your future self living in a new mansion, you imagine basking in splendor and everything feeling great. What’s easy to forget is that people in mansions can get the flu, have psoriasis, become embroiled in lawsuits, bicker with their spouses, are wracked with insecurity and annoyed with politicians – which in any given moment can supersede any joy that comes from material success. Future fortunes are imagined in a vacuum, but reality is always lived with the good and bad taken together, competing for attention. ([View Highlight](https://instapaper.com/read/1488781117/18970615))
