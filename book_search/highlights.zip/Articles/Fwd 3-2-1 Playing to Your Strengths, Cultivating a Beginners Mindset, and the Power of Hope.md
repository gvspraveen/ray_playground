# Fwd: 3-2-1: Playing to Your Strengths, Cultivating a Beginner's Mindset, and the Power of Hope

![](https://readwise-assets.s3.amazonaws.com/static/images/article0.00998d930354.png)

### Metadata

- Author: instapaper.com
- Full Title: Fwd: 3-2-1: Playing to Your Strengths, Cultivating a Beginner's Mindset, and the Power of Hope
- Category: #articles


- URL: https://instapaper.com/read/1500792305

### Highlights

- “A complex system that works is invariably found to have evolved from a simple system that worked. The inverse proposition also appears to be true: A complex system designed from scratch never works and cannot be made to work. You have to start over, beginning with a working simple system.” ([View Highlight](https://instapaper.com/read/1500792305/19362578))
