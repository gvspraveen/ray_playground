# Mission → Vision → Strategy → Goals → Roadmap → Task

![](https://readwise-assets.s3.amazonaws.com/static/images/article1.be68295a7e40.png)

### Metadata

- Author: Lenny's Newsletter
- Full Title: Mission → Vision → Strategy → Goals → Roadmap → Task
- Category: #articles

### Highlights

- ![](https://substackcdn.com/image/fetch/w_2912,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fbucketeer-e05bbc84-baa3-437e-9518-adb32be77984.s3.amazonaws.com%2Fpublic%2Fimages%2Fda08427f-3cd6-4a15-bb11-11d93c68ac0b_2400x1186.png) ([View Highlight](https://read.readwise.io/read/01gg0egb7z0ckzkr5ff8p5cjs4))
    - **Tags:** #leadership, #strategy
- ![](https://substackcdn.com/image/fetch/w_2912,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fbucketeer-e05bbc84-baa3-437e-9518-adb32be77984.s3.amazonaws.com%2Fpublic%2Fimages%2F2acf78ea-a0c1-4a10-a280-26fc3b055557_2400x1186.png) ([View Highlight](https://read.readwise.io/read/01gg0em33yhk6cdrtaagdprbhw))
    - **Tags:** #strategy
