# Should You Sell in May and Go Away? - Safal Niveshak

![](https://readwise-assets.s3.amazonaws.com/static/images/article0.00998d930354.png)

### Metadata

- Author: safalniveshak.com
- Full Title: Should You Sell in May and Go Away? - Safal Niveshak
- Category: #articles


- URL: https://www.safalniveshak.com/sell-in-may-and-go-away/

### Highlights

- You may hold on to the hope that you would isolate your gains, take them home, and throw your losses out. This has been the hope of every ambitious investor, but up to this day no one has succeeded. Anyone who goes after gains (pleasure) must not complain when he comes across losses (pain). Markets serve this reminder frequently, and we must accept this. ([View Highlight](https://instapaper.com/read/1505578316/19533735))
    - **Tags:** #finance
