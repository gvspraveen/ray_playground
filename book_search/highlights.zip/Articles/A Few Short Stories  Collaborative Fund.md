# A Few Short Stories · Collaborative Fund

![](https://readwise-assets.s3.amazonaws.com/static/images/article2.74d541386bbf.png)

### Metadata

- Author: collaborativefund.com
- Full Title: A Few Short Stories · Collaborative Fund
- Category: #articles


- URL: http://www.collaborativefund.com/blog/a-few-short-stories/

### Highlights

- It’s easy to underestimate how social norms stall change, even when the change is an obvious improvement. One of the strongest forces in the world is the urge to keep doing things as you’ve always done them, because people don’t like to be told they’ve been doing things wrong. Change eventually comes, but agonizingly slower than you might assume. ([View Highlight](https://instapaper.com/read/1408571946/16251764))
