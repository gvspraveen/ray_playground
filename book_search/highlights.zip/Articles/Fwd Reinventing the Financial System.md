# Fwd: Reinventing the Financial System

![](https://readwise-assets.s3.amazonaws.com/static/images/article1.be68295a7e40.png)

### Metadata

- Author: instapaper.com
- Full Title: Fwd: Reinventing the Financial System
- Category: #articles


- URL: https://instapaper.com/read/1419613761

### Highlights

- credit doesn’t come last, it comes first as the fundamental unit of commerce. Units of currency are abstract measures of debt and a coin is simply an IOU. In this sense, the value of a unit of currency is not the measure of the value of an object, but the measure of one’s trust in other human beings. ([View Highlight](https://instapaper.com/read/1419613761/16647265))
