# Fwd: Brain Food: Avoiding Problems, Decisions, and the Best Response for Avoiding Arguments

![](https://readwise-assets.s3.amazonaws.com/static/images/article1.be68295a7e40.png)

### Metadata

- Author: instapaper.com
- Full Title: Fwd: Brain Food: Avoiding Problems, Decisions, and the Best Response for Avoiding Arguments
- Category: #articles


- URL: https://instapaper.com/read/1389363410

### Highlights

- When it comes to making decisions, your environment matters. Just as it’s hard to eat healthy if your kitchen is full of junk food, it’s hard to make good decisions when you’re too busy to think. Just as the kitchen influences what you eat, your office influences how you make decisions. … Most of us make decisions in an environment where it is very hard for us to behave rationally. ([View Highlight](https://instapaper.com/read/1389363410/15590247))
    - **Tags:** #decision
