# Fwd: Brain Food: On Saying No, Knowledge, and Distortions

![](https://readwise-assets.s3.amazonaws.com/static/images/article3.5c705a01b476.png)

### Metadata

- Author: instapaper.com
- Full Title: Fwd: Brain Food: On Saying No, Knowledge, and Distortions
- Category: #articles


- URL: https://instapaper.com/read/1420062279

### Highlights

- Waiting for the right time is seductive. Our mind tricks us into thinking that waiting is actually doing something.
  It's easy to land in a state where you're always waiting ... for the right moment, for things to be perfect, for everything to feel just right. It's easy to convince yourself that you're not ready and if you wait just a little longer than things will be easier.
  Waiting rarely makes things easier. Most of the time, waiting makes things harder. ([View Highlight](https://instapaper.com/read/1420062279/16665815))
    - **Tags:** #habits
    - **Note:** taking action
