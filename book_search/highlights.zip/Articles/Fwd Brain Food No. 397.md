# Fwd: Brain Food No. 397

![](https://readwise-assets.s3.amazonaws.com/static/images/article3.5c705a01b476.png)

### Metadata

- Author: instapaper.com
- Full Title: Fwd: Brain Food No. 397
- Category: #articles


- URL: https://instapaper.com/read/1365813277

### Highlights

- Lesson 1: Tiny errors compound. Over a long enough time period, even small imperfections overpower perfect assumptions. Change is constant. Just as success plants the seeds of failure, failure plants the seeds of success. ([View Highlight](https://instapaper.com/read/1365813277/14727185))
    - **Tags:** #progress
- Eventually …. Execution beats luck Consistency beats intensity Curiosity beats smart
  Kind beats clever
  Together beats alone ([View Highlight](https://instapaper.com/read/1365813277/14727253))
