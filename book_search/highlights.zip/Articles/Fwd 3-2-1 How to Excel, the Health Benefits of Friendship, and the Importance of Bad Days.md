# Fwd: 3-2-1: How to Excel, the Health Benefits of Friendship, and the Importance of Bad Days

![](https://readwise-assets.s3.amazonaws.com/static/images/article4.6bc1851654a0.png)

### Metadata

- Author: instapaper.com
- Full Title: Fwd: 3-2-1: How to Excel, the Health Benefits of Friendship, and the Importance of Bad Days
- Category: #articles


- URL: https://instapaper.com/read/1432412834

### Highlights

- “The bad days are more important than the good days.
  If you write or exercise or meditate or cook when you don’t feel like it, then you maintain the habit.
  And if you maintain the habit, then all you need is time.” ([View Highlight](https://instapaper.com/read/1432412834/17060256))
    - **Tags:** #favorite, #habits
- [Tennis champion] Novak Djokovic said in an interview with the Financial Times that “I can carry on playing at this level because I like hitting the tennis ball.” The interviewer replied in surprise: “Are there really players who don’t like hitting the ball?” Djokovic answered, “Oh yes. There are people out there who don’t have the right motivation. You don’t need to talk to them. I can see it.”
  If you can find the thing you do for its own sake, the compulsive piece of your process, and dial that up and up, beyond the imaginary ceiling for that activity you may be creating, my experience is the world comes to you for that thing and you massively outperform the others who don’t actually like hitting that particular ball. I think the rest of career advice is commentary on this essential truth ([View Highlight](https://instapaper.com/read/1432412834/17060259))
    - **Tags:** #progress
