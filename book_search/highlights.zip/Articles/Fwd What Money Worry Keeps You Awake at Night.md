# Fwd: What Money Worry Keeps You Awake at Night?

![](https://readwise-assets.s3.amazonaws.com/static/images/article0.00998d930354.png)

### Metadata

- Author: instapaper.com
- Full Title: Fwd: What Money Worry Keeps You Awake at Night?
- Category: #articles


- URL: https://instapaper.com/read/1359828997

### Highlights

- You see, money is the chief cause of stress and insomnia for many of us and we should not ignore the symptoms. In fact, if you can get a handle on all your money worries by first knowing what they really are, your nights will be much peaceful and dreams much sweeter as a result. ([View Highlight](https://instapaper.com/read/1359828997/14527940))
    - **Tags:** #favorite, #finance
