# 10 Lessons From Great Businesses | the Generalist

![](https://readwise-assets.s3.amazonaws.com/static/images/article3.5c705a01b476.png)

### Metadata

- Author: Red Bull
- Full Title: 10 Lessons From Great Businesses | the Generalist
- Category: #articles


- URL: https://www.readthegeneralist.com/briefing/10-lessons

### Highlights

- Be a painfully persistent recruiter (Stripe)
  Maximize deep work time (Levels)
  Obsess over your customer (Coupang)
  Align the incentives (AngelList)
  Think like a nation-state (Terra)
  Invest in soft-power (FTX)
  Preserve optionality (OpenSea)
  Intensify your advantages (Tiger Global)
  Find your counter-positioning (Telegram)
  Proactively reinvent yourself (Many) ([View Highlight](https://instapaper.com/read/1490677403/19032377))
    - **Tags:** #strategy
