# Fwd: The Apple/Google Search Relationship as an Economic Template

![](https://readwise-assets.s3.amazonaws.com/static/images/article2.74d541386bbf.png)

### Metadata

- Author: instapaper.com
- Full Title: Fwd: The Apple/Google Search Relationship as an Economic Template
- Category: #articles


- URL: https://instapaper.com/read/1395416596

### Highlights

- antitrust cases always deal with snapshots in time, while the system they’re responding to is dynamic. Breaking up big tech companies can work, but it’s a race between the legal system and the game theory of tech companies doing it themselves. ([View Highlight](https://instapaper.com/read/1395416596/15813700))
