# Market Definitions and Tech Monopolies — Benedict Evans

![](https://readwise-assets.s3.amazonaws.com/static/images/article0.00998d930354.png)

### Metadata

- Author: ben-evans.com
- Full Title: Market Definitions and Tech Monopolies — Benedict Evans
- Category: #articles


- URL: https://www.ben-evans.com/benedictevans/2020/10/31/market-definitions-and-tech-monopolies

### Highlights

- The big shifts in dominance in tech in the last few decades have not generally come fro a new product that does the same thing as the old one, but from a company doing something that changes the field of play. Microsoft didn’t overturn IBM’s dominance of mainframes - instead, PCs made mainframes irrelevant. Google didn’t make a new Windows, and Facebook didn’t take on Google at web search - instead, they carved out something new. ([View Highlight](https://instapaper.com/read/1358058226/14477996))
    - **Tags:** #strategy
- The big shifts in dominance in tech in the last few decades have not generally come from a new product that does the same thing as the old one, but from a company doing something that changes the field of play. Microsoft didn’t overturn IBM’s dominance of mainframes - instead, PCs made mainframes irrelevant. Google didn’t make a new Windows, and Facebook didn’t take on Google at web search - instead, they carved out something new. ([View Highlight](https://instapaper.com/read/1358058226/15057489))
    - **Tags:** #business
