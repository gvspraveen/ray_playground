# Brain Food: Momentum Creates Motivation

![](https://readwise-assets.s3.amazonaws.com/static/images/article4.6bc1851654a0.png)

### Metadata

- Author: FS (Farnam Street)
- Full Title: Brain Food: Momentum Creates Motivation
- Category: #articles

### Highlights

- If you wait until you're motivated, you’ve already lost.
  Surgeons don’t always feel like doing surgery. Teachers don’t always feel like teaching. Parents don’t always feel like cooking. Firemen don’t always feel like rushing into a burning building.
  If you let motivation dictate your actions, inertia conspires to keep you in place.
  Action creates progress. Progress creates momentum. Momentum creates motivation. ([View Highlight](https://read.readwise.io/read/01gp99vrf5nz28gbd7w6a7c7cy))
    - **Tags:** #favorite, #habits
