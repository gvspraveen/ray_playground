# When Costs Are Nonlinear, Keep It Small. – Jessitron

![](https://readwise-assets.s3.amazonaws.com/static/images/article1.be68295a7e40.png)

### Metadata

- Author: jessitron.com
- Full Title: When Costs Are Nonlinear, Keep It Small. – Jessitron
- Category: #articles


- URL: https://jessitron.com/2021/01/18/when-costs-are-nonlinear-keep-it-small/

### Highlights

- Do the easy boring job regularly, instead of the hard scary job in a panic. ([View Highlight](https://instapaper.com/read/1380937180/15279606))
    - **Tags:** #favorite
