# Fwd: 3-2-1: On Hate as a Defense Mechanism, Reciprocity, and Consistency

![](https://readwise-assets.s3.amazonaws.com/static/images/article1.be68295a7e40.png)

### Metadata

- Author: instapaper.com
- Full Title: Fwd: 3-2-1: On Hate as a Defense Mechanism, Reciprocity, and Consistency
- Category: #articles


- URL: https://instapaper.com/read/1392533802

### Highlights

- Writing one essay rarely matters. Write every day and you’re practically a hero.
  Unheroic days can make for heroic decades ([View Highlight](https://instapaper.com/read/1392533802/15704653))
    - **Tags:** #compounding, #habits
