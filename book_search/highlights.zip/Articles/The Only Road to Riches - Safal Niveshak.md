# The Only Road to Riches - Safal Niveshak

![](https://readwise-assets.s3.amazonaws.com/static/images/article4.6bc1851654a0.png)

### Metadata

- Author: safalniveshak.com
- Full Title: The Only Road to Riches - Safal Niveshak
- Category: #articles


- URL: https://www.safalniveshak.com/only-road-to-riches/

### Highlights

- Survival is the only road to riches. Let me say that again: Survival is the only road to riches. You should try to maximize return only if losses would not threaten your survival and if you have a compelling future need for the extra gains you might earn ([View Highlight](https://instapaper.com/read/1463586914/18095936))
