# 3-2-1: The Will to Win, Capturing Experiences, and the Difference Between Creativity and Efficiency

![](https://readwise-assets.s3.amazonaws.com/static/images/article2.74d541386bbf.png)

### Metadata

- Author: James Clear
- Full Title: 3-2-1: The Will to Win, Capturing Experiences, and the Difference Between Creativity and Efficiency
- Category: #articles

### Highlights

- "Be great in small ways.
  Writing 100 words today doesn’t seem worthwhile when you see people publishing bestsellers.
  Exercising for 10 minutes doesn’t seem valuable when you see world records posted on Instagram.
  But winning the next 10 minutes is its own form of greatness.
  People are so busy wishing for more time and better resources that they fail to make the most of the time and resources they have. Be great in small ways and you may be surprised by what you've achieved within a year or two." ([View Highlight](https://read.readwise.io/read/01gbxha7q80yvkbtz0hkene07d))
    - **Tags:** #habits, #favorite
