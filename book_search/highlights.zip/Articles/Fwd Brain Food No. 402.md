# Fwd: Brain Food No. 402

![](https://readwise-assets.s3.amazonaws.com/static/images/article4.6bc1851654a0.png)

### Metadata

- Author: instapaper.com
- Full Title: Fwd: Brain Food No. 402
- Category: #articles


- URL: https://instapaper.com/read/1375077270

### Highlights

- “I just try and avoid being stupid. I have a way of handling a lot of problems. I put them on what I call my too-hard pile. Then I just leave them there. I’m not trying to succeed in my too-hard pile.”
  — Charlie Munger (in this at Caltech from last week. Complement with this talk on the Psychology of Human Misjudgment) ([View Highlight](https://instapaper.com/read/1375077270/15060367))
    - **Tags:** #favorite
