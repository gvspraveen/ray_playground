# The Highest Forms of Wealth · Collaborative Fund

![](https://readwise-assets.s3.amazonaws.com/static/images/article1.be68295a7e40.png)

### Metadata

- Author: collaborativefund.com
- Full Title: The Highest Forms of Wealth · Collaborative Fund
- Category: #articles


- URL: http://www.collaborativefund.com/blog/the-highest-forms-of-wealth/

### Highlights

- A person whose expectations relative to income are calibrated so they don’t even have to think about money has a higher form of wealth than someone with more money who’s constantly thinking about making the numbers work. ([View Highlight](https://instapaper.com/read/1431242661/17025197))
    - **Tags:** #finance
