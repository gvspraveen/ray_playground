# Fwd: 3-2-1: On Growth Through Challenges, All-or-Nothing Mindsets, and Great Art Evolving With Us

![](https://readwise-assets.s3.amazonaws.com/static/images/article2.74d541386bbf.png)

### Metadata

- Author: instapaper.com
- Full Title: Fwd: 3-2-1: On Growth Through Challenges, All-or-Nothing Mindsets, and Great Art Evolving With Us
- Category: #articles


- URL: https://instapaper.com/read/1417418920

### Highlights

- That’s true whether you are starting a business, having a child, changing careers, or wrestling with any number of challenges. That’s not a license to be reckless and never think things through, but at some point you have to embrace the uncertainty because it is the only path forward. ([View Highlight](https://instapaper.com/read/1417418920/16574263))
