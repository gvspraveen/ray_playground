# Playing on Hard Mode – Stratechery by Ben Thompson

![](https://readwise-assets.s3.amazonaws.com/static/images/article1.be68295a7e40.png)

### Metadata

- Author: stratechery.com
- Full Title: Playing on Hard Mode – Stratechery by Ben Thompson
- Category: #articles


- URL: https://stratechery.com/2020/playing-on-hard-mode/

### Highlights

- but also finding a business model that was native as well. ([View Highlight](https://instapaper.com/read/1362530723/14613248))
    - **Note:** every medium needs a different kind of business model.
