# Fwd: Dee Hock, the Father of Fintech

![](https://readwise-assets.s3.amazonaws.com/static/images/article1.be68295a7e40.png)

### Metadata

- Author: instapaper.com
- Full Title: Fwd: Dee Hock, the Father of Fintech
- Category: #articles


- URL: https://instapaper.com/read/1376527242

### Highlights

- Understanding events and inﬂuencing the future requires mastering of four ways of looking at things; as they were, as they are, as they might become, and as they ought to be ([View Highlight](https://instapaper.com/read/1376527242/15114531))
    - **Tags:** #innovation
