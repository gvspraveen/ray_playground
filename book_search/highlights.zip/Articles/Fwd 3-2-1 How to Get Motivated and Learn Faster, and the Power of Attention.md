# Fwd: 3-2-1: How to Get Motivated and Learn Faster, and the Power of Attention

![](https://readwise-assets.s3.amazonaws.com/static/images/article0.00998d930354.png)

### Metadata

- Author: instapaper.com
- Full Title: Fwd: 3-2-1: How to Get Motivated and Learn Faster, and the Power of Attention
- Category: #articles


- URL: https://instapaper.com/read/1421137512

### Highlights

- "Motivation often comes after starting, not before.
  Action produces momentum." ([View Highlight](https://instapaper.com/read/1421137512/16698700))
    - **Tags:** #progress
