# Fwd: 3-2-1: How to Rebound From a Mistake and Think Outside Your Constraints

![](https://readwise-assets.s3.amazonaws.com/static/images/article3.5c705a01b476.png)

### Metadata

- Author: instapaper.com
- Full Title: Fwd: 3-2-1: How to Rebound From a Mistake and Think Outside Your Constraints
- Category: #articles


- URL: https://instapaper.com/read/1419304731

### Highlights

- Your mind is a suggestion engine. Every thought you have is a suggestion, not an order.
  Sometimes your mind suggests that you are tired, that you should give up, or that you should take an easier path.
  But if you pause, you can discover new suggestions. For example, that you will feel good once the work is done or that you have the ability to finish things even when you don't feel like it.
  Your thoughts are not orders. Merely suggestions. You have the power to choose which option to follow ([View Highlight](https://instapaper.com/read/1419304731/16638067))
    - **Tags:** #habits
