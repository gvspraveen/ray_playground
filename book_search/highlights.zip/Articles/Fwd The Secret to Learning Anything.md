# Fwd: The Secret to Learning Anything

![](https://readwise-assets.s3.amazonaws.com/static/images/article1.be68295a7e40.png)

### Metadata

- Author: instapaper.com
- Full Title: Fwd: The Secret to Learning Anything
- Category: #articles


- URL: https://instapaper.com/read/1359616639

### Highlights

- the way to learn the most is…when you are doing something with such enjoyment that you don’t notice that the time passes ([View Highlight](https://instapaper.com/read/1359616639/14521423))
    - **Tags:** #learning
