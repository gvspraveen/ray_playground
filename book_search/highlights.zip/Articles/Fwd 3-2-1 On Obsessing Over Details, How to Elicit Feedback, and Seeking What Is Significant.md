# Fwd: 3-2-1: On Obsessing Over Details, How to Elicit Feedback, and Seeking What Is Significant

![](https://readwise-assets.s3.amazonaws.com/static/images/article3.5c705a01b476.png)

### Metadata

- Author: instapaper.com
- Full Title: Fwd: 3-2-1: On Obsessing Over Details, How to Elicit Feedback, and Seeking What Is Significant
- Category: #articles


- URL: https://instapaper.com/read/1398313520

### Highlights

- “Habits are the compound interest of self-improvement.
  A small habit—when repeated consistently—grows into something significant.” ([View Highlight](https://instapaper.com/read/1398313520/15907993))
    - **Tags:** #habits, #compounding
