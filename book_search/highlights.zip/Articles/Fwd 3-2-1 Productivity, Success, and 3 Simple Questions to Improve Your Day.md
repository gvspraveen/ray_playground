# Fwd: 3-2-1: Productivity, Success, and 3 Simple Questions to Improve Your Day

![](https://readwise-assets.s3.amazonaws.com/static/images/article2.74d541386bbf.png)

### Metadata

- Author: instapaper.com
- Full Title: Fwd: 3-2-1: Productivity, Success, and 3 Simple Questions to Improve Your Day
- Category: #articles


- URL: https://instapaper.com/read/1477004337

### Highlights

- “People often think it’s weird to get hyped about reading one page or meditating for one minute or making one sales call. But the point is not to do one thing. The point is to master the habit of showing up. The truth is, a habit must be established before it can be improved. If you can’t learn the basic skill of showing up, then you have little hope of mastering the finer details. Instead of trying to engineer a perfect habit from the start, do the easy thing on a more consistent basis. You have to standardize before you can optimize.” ([View Highlight](https://instapaper.com/read/1477004337/18569539))
    - **Tags:** #habits
