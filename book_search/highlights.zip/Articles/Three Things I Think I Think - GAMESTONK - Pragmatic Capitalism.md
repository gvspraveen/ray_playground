# Three Things I Think I Think - GAMESTONK! - Pragmatic Capitalism

![](https://readwise-assets.s3.amazonaws.com/static/images/article1.be68295a7e40.png)

### Metadata

- Author: Cullen Roche
- Full Title: Three Things I Think I Think - GAMESTONK! - Pragmatic Capitalism
- Category: #articles


- URL: https://www.pragcap.com/three-things-i-think-i-think-gamestonk/

### Highlights

- itcoin itself is actually decentralized. But if Bitcoin is the center of the crypto ecosystem and you want to create a financial system that branches off from this that gives people access to things like credit and stock markets then you’re gonna end up creating a largely centralized system. So this fairy tale about a fully decentralized financial system is just that. ([View Highlight](https://instapaper.com/read/1382416384/15333556))
    - **Tags:** #bitcoin
