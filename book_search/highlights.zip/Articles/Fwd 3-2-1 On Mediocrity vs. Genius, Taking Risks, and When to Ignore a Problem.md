# Fwd: 3-2-1: On Mediocrity vs. Genius, Taking Risks, and When to Ignore a Problem

![](https://readwise-assets.s3.amazonaws.com/static/images/article1.be68295a7e40.png)

### Metadata

- Author: instapaper.com
- Full Title: Fwd: 3-2-1: On Mediocrity vs. Genius, Taking Risks, and When to Ignore a Problem
- Category: #articles


- URL: https://instapaper.com/read/1396416206

### Highlights

- “New goals don’t deliver new results. New lifestyles do.
  And a lifestyle is a process, not an outcome.
  For this reason, your energy should go into building better habits, not chasing better results.” ([View Highlight](https://instapaper.com/read/1396416206/15845180))
    - **Tags:** #habits
- “Everything good needs time. Don’t do work in a hurry. Go into details; it pays in every way. Time means power for your work. Mediocrity is always in a rush; but whatever is worth doing at all is worth doing with consideration. For genius is nothing more nor less than doing well what anyone can do badly.” ([View Highlight](https://instapaper.com/read/1396416206/15845186))
