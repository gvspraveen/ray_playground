# Ironies of Luck · Collaborative Fund

![](https://readwise-assets.s3.amazonaws.com/static/images/article3.5c705a01b476.png)

### Metadata

- Author: collaborativefund.com
- Full Title: Ironies of Luck · Collaborative Fund
- Category: #articles

- Document Tags: #Liked  
- URL: http://www.collaborativefund.com/blog/ironies-of-luck/

### Highlights

- Experiencing risk reduces confidence when it should merely highlight reality, which can make people more conservative than they should be. Luck increases confidence without increasing ability, which also magnifies how people respond to it. ([View Highlight](https://instapaper.com/read/1420061183/16665771))
