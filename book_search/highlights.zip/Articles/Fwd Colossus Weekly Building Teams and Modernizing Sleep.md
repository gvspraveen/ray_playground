# Fwd: Colossus Weekly: Building Teams and Modernizing Sleep

![](https://readwise-assets.s3.amazonaws.com/static/images/article0.00998d930354.png)

### Metadata

- Author: instapaper.com
- Full Title: Fwd: Colossus Weekly: Building Teams and Modernizing Sleep
- Category: #articles


- URL: https://instapaper.com/read/1393310120

### Highlights

- Focus your time and energy on your processes aka “hitting the gym”. Focus on getting your reps and sets in, tweaking your form, and most important of all, maintaining consistency. Whether this means acquiring industry-specific knowledge, building systems, honing skills, expanding your network, or just growing your experience. Don’t skip leg days, as a matter of fact, don’t skip any days. Every day you hit the gym, the effects compound, even though you won’t see visible results until far into the future ([View Highlight](https://instapaper.com/read/1393310120/15735103))
    - **Tags:** #habits, #process
