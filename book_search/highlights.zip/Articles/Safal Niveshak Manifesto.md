# Safal Niveshak Manifesto

![](https://readwise-assets.s3.amazonaws.com/static/images/article3.5c705a01b476.png)

### Metadata

- Author: Vishal Khandelwal
- Full Title: Safal Niveshak Manifesto
- Category: #articles


- URL: https://www.safalniveshak.com/wp-content/uploads/2022/11/Safal-Niveshak-Manifesto.pdf?utm_source=newsletter&utm_medium=email&utm_campaign=the_investor_s_manifesto&utm_term=2022-11-14

### Highlights

- I AM AN INVESTOR.
  THE INVESTOR'S MANIFESTO
  WWW.SAFALNIVESHAK.COM
  I AM NOT A SPECULATOR.
  IT'S NOT HOW MUCH MONEY I MAKE THAT MATTERS,
  BUT HOW MUCH MONEY I KEEP, HOW HARD IT WORKS,
  AND HOW MANY YEARS I LET IT WORK.
  .............................................................................................
  PATIENCE IS A VIRTUE FOR ME.
  I RESIST THE NATURAL HUMAN BIAS TO ACT.
  I AM NOT AS BRAVE
  AS MY BROKER THINKS I AM.
  FOR ME, LOSS PREVENTION
  IS MORE IMPORTANT THAN
  PURSUIT OF GAIN.
  .......................................................................................................................................................................
  I KNOW IF I KEEP AT HARD WORK AND HONESTY,
  I WILL GET ALMOST ANYTHING IN LIFE. INVESTING ISN’T DIFFERENT.
  .......................................................................................................................................................................
  I DON’T TRY TO
  PREDICT THE FUTURE.
  I ALWAYS TRY TO
  PREPARE FOR IT.
  I KNOW THAT TO MAKE MONEY
  IN STOCKS, I MUST HAVE
  VISION TO SEE THEM,
  COURAGE TO BUY THEM,
  AND PATIENCE TO HOLD THEM.
  I UNDERSTAND THAT LUCK
  PLAYS A LARGE ROLE IN
  SUCCESS IN INVESTING.
  NOT GIVING IT DUE CREDIT
  WOULD LEAD ME TO FAILURE.
  .......................................................................................................................................................................
  I UNDERSTAND THAT KNOWING
  WHAT I DON'T KNOW
  IS MORE USEFUL
  TH A N BE I NG BR I L L I A N T .
  I KNOW LEVERAGE WHEN COMBINED
  WITH STOCK MARKET VOLATILITY
  EQUALS DYNAMITE, AND THUS
  I KEEP MYSELF FAR AWAY FROM IT.
  .......................................................................................................................................................................
  FOR ME, THERE IS NO
  SUCH THING AS GETTING
  RICH QUICK.
  I KNOW THERE IS NO EASY ROAD.
  THE MOMENT I BELIEVE THE ROAD IS
  EASY, I WILL PUT MYSELF AT GREAT RISK.
  I KNOW WHAT I OWN,
  AND WHY I OWN IT.
  .......................................................................................................................................................................
  I REMEMBER THAT THE MOST
  DANGEROUS WORDS IN INVESTING ARE
  'THIS TIME IT'S DIFFERENT.'
  I KNOW TO ACHIEVE SUCCESS AS AN INVESTOR
  I DON’T HAVE TO BE BRILLIANT, BUT ONLY A LITTLE BIT
  WISER THAN OTHERS, ON AVERAGE, FOR A LONG, LONG TIME.
  .......................................................................................................................................................................
  I KNOW THAT IN INVESTING, I ONLY HAVE TO DO FEW THINGS RIGHT
  SO LONG AS I DO NOT DO TOO MANY THINGS WRONG.
  .......................................................................................................................................................................
  I CAN’T LIVE LONG ENOUGH TO MAKE
  ALL INVESTING MISTAKES MYSELF.
  I MUST THUS LEARN FROM
  THE MISTAKES OF OTHERS.
  I TRY TO KEEP MY HEAD WHEN OTHERS ARE LOSING THEIRS.
  SUCCESSFUL INVESTING FOR ME IS 99%
  TEMPERAMENT AND 1% INTELLIGENCE.
  .......................................................................................................................................................................
  HUMILITY AND COURAGE ARE MY GREATEST ASSETS AS AN INVESTOR. I MUST NOT LOSE THEM.
  I REMIND MYSELF OFTEN:
  I AM AN INVESTOR.
  WWW.SAFALNIVESHAK.COM
  ...........
  .....................
  ...............
  ......................
  ...........
  ...........................
  .....................
  . ([View Highlight](https://read.readwise.io/read/01ghvz4v1b80s7x058p83rzekd))
    - **Tags:** #finance
