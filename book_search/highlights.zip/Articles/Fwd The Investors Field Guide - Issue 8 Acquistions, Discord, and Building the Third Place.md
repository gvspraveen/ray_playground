# Fwd: The Investor's Field Guide - Issue 8: Acquistions, Discord, and Building the Third Place

![](https://readwise-assets.s3.amazonaws.com/static/images/article4.6bc1851654a0.png)

### Metadata

- Author: instapaper.com
- Full Title: Fwd: The Investor's Field Guide - Issue 8: Acquistions, Discord, and Building the Third Place
- Category: #articles


- URL: https://instapaper.com/read/1355261962

### Highlights

- The driving force of the massive amount of value creation on basically every single one were network effects on the internet, the fact that these companies in large part had zero marginal costs and also in large part had zero distribution costs … And the way that that sort of shakes out to me is that tech businesses are just media businesses from the sort of ’70s and ’80s but with one more steroid injection to their business model ([View Highlight](https://instapaper.com/read/1355261962/14390825))
    - **Tags:** #strategy, #favorite, #business
