# Fwd: What's Happening in Logistics

![](https://readwise-assets.s3.amazonaws.com/static/images/article0.00998d930354.png)

### Metadata

- Author: instapaper.com
- Full Title: Fwd: What's Happening in Logistics
- Category: #articles


- URL: https://instapaper.com/read/1371165344

### Highlights

- The odd competitive dynamic is that shipping speed advantages vary at different points: Amazon is the best place to buy many products if you need them in two days, but its competitors are often better when you need the product either a) some time this week, or b) in the next hour. ([View Highlight](https://instapaper.com/read/1371165344/14905186))
- New technologies don’t just catch up; they can surpass ([View Highlight](https://instapaper.com/read/1371165344/14905225))
