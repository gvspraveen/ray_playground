# Fwd: 3-2-1: Leave Room for the Unexpected

![](https://readwise-assets.s3.amazonaws.com/static/images/article3.5c705a01b476.png)

### Metadata

- Author: instapaper.com
- Full Title: Fwd: 3-2-1: Leave Room for the Unexpected
- Category: #articles


- URL: https://instapaper.com/read/1447036154

### Highlights

- “Always leave room for the unexpected. A buffer of time, a little extra money, a reserve of goodwill.
  You won’t be maximizing every opportunity or squeezing out every last dollar, but what you lose in reward, you gain in safety.
  Survival is the highest return of all.” ([View Highlight](https://instapaper.com/read/1447036154/17540285))
    - **Tags:** #favorite
