# Why Are We Panicking Again? – Of Dollars and Data

![](https://readwise-assets.s3.amazonaws.com/static/images/article4.6bc1851654a0.png)

### Metadata

- Author: Nick Maggiulli
- Full Title: Why Are We Panicking Again? – Of Dollars and Data
- Category: #articles


- URL: https://ofdollarsanddata.com/why-are-we-panicking-again/

### Highlights

- No one wants to talk about the power of compounding or building wealth over the long term. But that’s where most true fortunes are made! It’s very rare that someone gets rich (and stays rich) by making big bets often. The double-edged sword usually comes for them eventually. ([View Highlight](https://instapaper.com/read/1392854529/15713347))
    - **Tags:** #compounding, #finance
