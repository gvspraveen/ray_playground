# Fwd: The Web’s Missing Interoperability

![](https://readwise-assets.s3.amazonaws.com/static/images/article3.5c705a01b476.png)

### Metadata

- Author: instapaper.com
- Full Title: Fwd: The Web’s Missing Interoperability
- Category: #articles


- URL: https://instapaper.com/read/1391899536

### Highlights

- egulators that truly wish to limit tech power and unlock the economic potential of the Internet would do well to prioritize competition and interoperability, particularly social graph sharing, alongside a more nuanced view of privacy that reflects reality, not misleading ads ([View Highlight](https://instapaper.com/read/1391899536/15683267))
