# Fwd: When the World's Top Economic Think Tank Was Located in Redmond, Washington

![](https://readwise-assets.s3.amazonaws.com/static/images/article2.74d541386bbf.png)

### Metadata

- Author: instapaper.com
- Full Title: Fwd: When the World's Top Economic Think Tank Was Located in Redmond, Washington
- Category: #articles


- URL: https://instapaper.com/read/1383823293

### Highlights

- Hiring smart people over specialists means hiring people who can apply their talents to whatever they happen to be interested in, and hiring for openness over agreeableness means hiring people who will compete to be the first to know about some amazing new trend. Paying people in options means having an employee base that’s very concerned with what could happen to their net worth if the company is blindsided (and diversification wouldn’t necessarily help; a Microsoft employee who sold their stock to buy a house in Redmond was trading a direct long-MSFT position for a synthetic one). ([View Highlight](https://instapaper.com/read/1383823293/15389615))
    - **Tags:** #incentives
