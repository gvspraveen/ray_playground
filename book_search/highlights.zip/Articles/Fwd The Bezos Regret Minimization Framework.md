# Fwd: The Bezos Regret Minimization Framework

![](https://readwise-assets.s3.amazonaws.com/static/images/article3.5c705a01b476.png)

### Metadata

- Author: instapaper.com
- Full Title: Fwd: The Bezos Regret Minimization Framework
- Category: #articles


- URL: https://instapaper.com/read/1390569662

### Highlights

- The Regret Minimization Framework is simple.
  The goal is to minimize the number of regrets in life.
  So when faced with a difficult decision:
  Project yourself forward into the future.
  Look back on the decision.
  Ask “Will I regret not doing this?”
  Act accordingly. ([View Highlight](https://instapaper.com/read/1390569662/15632107))
    - **Tags:** #favorite, #decision
