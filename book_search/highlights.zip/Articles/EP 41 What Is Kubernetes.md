# EP 41: What Is Kubernetes?

![](https://readwise-assets.s3.amazonaws.com/static/images/article2.74d541386bbf.png)

### Metadata

- Author: ByteByteGo
- Full Title: EP 41: What Is Kubernetes?
- Category: #articles

### Highlights

- [![](https://substackcdn.com/image/fetch/w_304,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F364bcb4b-284c-4d16-9cc8-d9e0b68bf713_800x1182.jpeg)](https://substack.com/redirect/838b94ac-cdc1-4066-a1fa-721ec76b8cef?j=eyJ1IjoieXhwbyJ9.DEqSmjn28hY_v2c0e6dyUAoIQ8blC09zantMWqt8OV4) ([View Highlight](https://read.readwise.io/read/01gprsxw7vznpsyqwse8as8g96))
