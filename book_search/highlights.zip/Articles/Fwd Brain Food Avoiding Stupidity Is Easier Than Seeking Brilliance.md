# Fwd: Brain Food: Avoiding Stupidity Is Easier Than Seeking Brilliance

![](https://readwise-assets.s3.amazonaws.com/static/images/article4.6bc1851654a0.png)

### Metadata

- Author: instapaper.com
- Full Title: Fwd: Brain Food: Avoiding Stupidity Is Easier Than Seeking Brilliance
- Category: #articles


- URL: https://instapaper.com/read/1460354400

### Highlights

- Things that reduce the odds of long-term success:
  A lack of focus.Making excuses.Staying up late.Eating poorly.Checking email first thing in the AM.Working more to fix being busy.Buying things you don’t have the money for.Focusing on yourself.Letting other people define success for you.
  The wrong relationships.
  A lack of patience. ([View Highlight](https://instapaper.com/read/1460354400/17992470))
    - **Tags:** #progress
