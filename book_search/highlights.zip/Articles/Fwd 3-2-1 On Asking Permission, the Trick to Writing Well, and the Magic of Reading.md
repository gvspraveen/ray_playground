# Fwd: 3-2-1: On Asking Permission, the Trick to Writing Well, and the Magic of Reading

![](https://readwise-assets.s3.amazonaws.com/static/images/article1.be68295a7e40.png)

### Metadata

- Author: instapaper.com
- Full Title: Fwd: 3-2-1: On Asking Permission, the Trick to Writing Well, and the Magic of Reading
- Category: #articles


- URL: https://instapaper.com/read/1358788923

### Highlights

- “The trick to writing well is to…
  - take long sentences and make them short
  - take confusing ideas and make them clear
  - take unrelated concepts and make them related
  …without losing the main idea in the process. ([View Highlight](https://instapaper.com/read/1358788923/14505426))
