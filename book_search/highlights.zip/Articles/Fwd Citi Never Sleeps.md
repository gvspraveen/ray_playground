# Fwd: Citi Never Sleeps

![](https://readwise-assets.s3.amazonaws.com/static/images/article4.6bc1851654a0.png)

### Metadata

- Author: instapaper.com
- Full Title: Fwd: Citi Never Sleeps
- Category: #articles


- URL: https://instapaper.com/read/1390860992

### Highlights

- As Howard Marks says:
  Rule number one: most things will prove to be cyclical. 
  Rule number two: some of the greatest opportunities for gain and loss come when other people forget rule number one. ([View Highlight](https://instapaper.com/read/1390860992/15644313))
    - **Tags:** #finance
