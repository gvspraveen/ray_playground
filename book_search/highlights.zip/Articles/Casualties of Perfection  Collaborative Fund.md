# Casualties of Perfection · Collaborative Fund

![](https://readwise-assets.s3.amazonaws.com/static/images/article4.6bc1851654a0.png)

### Metadata

- Author: collaborativefund.com
- Full Title: Casualties of Perfection · Collaborative Fund
- Category: #articles


- URL: http://www.collaborativefund.com/blog/inefficient/

### Highlights

- Concentration is the best way to maximize returns, but diversification is the best way to increase the odds of owning a company capable of delivering returns. On and on, if you’re honest with yourself you’ll see that a little inefficiency is the ideal spot to be in.
  Just like evolution, the key is realizing that the more perfect you try to become the more vulnerable you generally are. ([View Highlight](https://instapaper.com/read/1427305917/16896475))
