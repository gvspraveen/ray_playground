# Fwd: 3-2-1: Mental Toughness, the Connection Between Action and Satisfaction, and Mistakes

![](https://readwise-assets.s3.amazonaws.com/static/images/article4.6bc1851654a0.png)

### Metadata

- Author: instapaper.com
- Full Title: Fwd: 3-2-1: Mental Toughness, the Connection Between Action and Satisfaction, and Mistakes
- Category: #articles


- URL: https://instapaper.com/read/1516266393

### Highlights

- Look at a day when you are supremely satisfied at the end. It’s not a day when you lounge around doing nothing; it’s a day you’ve had everything to do and you’ve done it.” ([View Highlight](https://instapaper.com/read/1516266393/19882392))
