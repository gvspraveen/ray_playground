# Fwd: Four Refoundings

![](https://readwise-assets.s3.amazonaws.com/static/images/article0.00998d930354.png)

### Metadata

- Author: instapaper.com
- Full Title: Fwd: Four Refoundings
- Category: #articles


- URL: https://instapaper.com/read/1384790926

### Highlights

- The ideal time for a refounding is when a company looks unbeatable from the outside and vulnerable from the inside. That makes it an uncomfortable choice, but a necessary one ([View Highlight](https://instapaper.com/read/1384790926/15419014))
