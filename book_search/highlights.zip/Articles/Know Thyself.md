# Know Thyself

![](https://readwise-assets.s3.amazonaws.com/static/images/article2.74d541386bbf.png)

### Metadata

- Author: boz.com
- Full Title: Know Thyself
- Category: #articles


- URL: https://boz.com/articles/know-thyself

### Highlights

- My second bit of advice is to interrogate your identity on a regular basis. Your motivations change as you age and often without you consciously realizing it. You may start out motivated by the opinions of others and grow to find you have stronger intrinsic motivation. You may find that life changes like getting married or having kids realign your interests. One of the best ways to detect this gap is to catalog where you spend your time and what gives you energy and what seems to take energy away from you. Once you accept who you are today you can shift to crafting who you want to be tomorrow. ([View Highlight](https://instapaper.com/read/1414650260/16482097))
    - **Tags:** #progress
