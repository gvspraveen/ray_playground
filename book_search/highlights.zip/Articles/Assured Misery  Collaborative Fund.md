# Assured Misery · Collaborative Fund

![](https://readwise-assets.s3.amazonaws.com/static/images/article4.6bc1851654a0.png)

### Metadata

- Author: collaborativefund.com
- Full Title: Assured Misery · Collaborative Fund
- Category: #articles


- URL: http://www.collaborativefund.com/blog/assured-misery/

### Highlights

- The problem is that when you are keenly aware of your own struggles but blind to others’, it’s easy to assume you’re missing some skill or secret that others have. It’s a sure path to feeling inadequate.
  Everyone’s dealing with problems they don’t advertise, at least until you get to know them well. Keep that in mind and you become less envious and more forgiving – to yourself and others. ([View Highlight](https://instapaper.com/read/1467487613/18232587))
    - **Tags:** #favorite
