# Monday 3-2-1 – Good Monoliths, Career Tracks, Web3 Failures💡

![](https://readwise-assets.s3.amazonaws.com/static/images/article2.74d541386bbf.png)

### Metadata

- Author: 🌀 Luca from Refactoring
- Full Title: Monday 3-2-1 – Good Monoliths, Career Tracks, Web3 Failures💡
- Category: #articles

### Highlights

- [Gall's Law](https://substack.com/redirect/ac90832f-b8c9-4419-9add-ddf87cacfbb3?r=yxpo) :
  > *A complex system that works is invariably found to have evolved from a simple system that worked. A complex system designed from scratch never works and cannot be patched up to make it work. You have to start over with a working simple system.* ([View Highlight](https://read.readwise.io/read/01gk0ht5f63kwb2mxk3cc8e934))
    - **Tags:** #engineering, #leadership, #favorite
