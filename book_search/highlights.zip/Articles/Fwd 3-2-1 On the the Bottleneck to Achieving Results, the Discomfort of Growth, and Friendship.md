# Fwd: 3-2-1: On the the Bottleneck to Achieving Results, the Discomfort of Growth, and Friendship

![](https://readwise-assets.s3.amazonaws.com/static/images/article3.5c705a01b476.png)

### Metadata

- Author: instapaper.com
- Full Title: Fwd: 3-2-1: On the the Bottleneck to Achieving Results, the Discomfort of Growth, and Friendship
- Category: #articles


- URL: https://instapaper.com/read/1408034347

### Highlights

- "In many cases, the bottleneck to achieving results is simply making the time to do the work.
  You're capable of exercising, but are you making the time?
  You're capable of writing, but are you making the time?
  You're capable of reading, but are you making the time?" ([View Highlight](https://instapaper.com/read/1408034347/16232705))
    - **Tags:** #habits, #favorite
