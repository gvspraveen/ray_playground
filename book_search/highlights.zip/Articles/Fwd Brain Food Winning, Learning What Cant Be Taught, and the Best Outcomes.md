# Fwd: Brain Food: Winning, Learning What Can't Be Taught, and the Best Outcomes

![](https://readwise-assets.s3.amazonaws.com/static/images/article4.6bc1851654a0.png)

### Metadata

- Author: instapaper.com
- Full Title: Fwd: Brain Food: Winning, Learning What Can't Be Taught, and the Best Outcomes
- Category: #articles


- URL: https://instapaper.com/read/1385266738

### Highlights

- If you want above average results, you have to say no to average opportunities.
  If you spend all of your time chasing average opportunities, you’ll have no time for great ones. This applies to people, books, problems, etc.
  Raise the bar. ([View Highlight](https://instapaper.com/read/1385266738/15437050))
    - **Tags:** #favorite
