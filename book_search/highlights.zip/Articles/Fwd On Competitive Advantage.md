# Fwd: On Competitive Advantage

![](https://readwise-assets.s3.amazonaws.com/static/images/article2.74d541386bbf.png)

### Metadata

- Author: instapaper.com
- Full Title: Fwd: On Competitive Advantage
- Category: #articles


- URL: https://instapaper.com/read/1397110965

### Highlights

- Intellectual curiosity is a real-world superpower.
  We all have it, but most will never embrace it.
  For the curious mind, anything is possible.
  Fortune favors the curious mind. ([View Highlight](https://instapaper.com/read/1397110965/15869614))
    - **Tags:** #favorite
