# Fwd: My "Multibagger" Idea That Will Never Disappoint You

![](https://readwise-assets.s3.amazonaws.com/static/images/article1.be68295a7e40.png)

### Metadata

- Author: instapaper.com
- Full Title: Fwd: My "Multibagger" Idea That Will Never Disappoint You
- Category: #articles


- URL: https://instapaper.com/read/1361644293

### Highlights

- Keep learning, be tentative in your decision making, change your mind if the facts change, diversify, and please don’t go around boasting about your successes. Only then can you dispel the darkness of your ignorance ([View Highlight](https://instapaper.com/read/1361644293/14579828))
    - **Tags:** #decision
