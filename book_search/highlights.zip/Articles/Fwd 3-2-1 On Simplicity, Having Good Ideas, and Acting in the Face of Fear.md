# Fwd: 3-2-1: On Simplicity, Having Good Ideas, and Acting in the Face of Fear

![](https://readwise-assets.s3.amazonaws.com/static/images/article0.00998d930354.png)

### Metadata

- Author: instapaper.com
- Full Title: Fwd: 3-2-1: On Simplicity, Having Good Ideas, and Acting in the Face of Fear
- Category: #articles


- URL: https://instapaper.com/read/1361644967

### Highlights

- The world is complex and there is no single path to a success. Look for patterns that are repeated across many successful people, not single stories ([View Highlight](https://instapaper.com/read/1361644967/14579846))
    - **Tags:** #progress
