# 3-2-1: Outsmarting Yourself, Staying Adaptable, and Choosing More Empowering Self-Talk

![](https://readwise-assets.s3.amazonaws.com/static/images/article4.6bc1851654a0.png)

### Metadata

- Author: James Clear
- Full Title: 3-2-1: Outsmarting Yourself, Staying Adaptable, and Choosing More Empowering Self-Talk
- Category: #articles

### Highlights

- "One of the great gift of sports is learning how to fail in public.
  People never go to the gym because they're scared of looking stupid, never share their writing because they're scared of judgment, never open their heart because they're scared of rejection.
  Sports train you to face your fear." ([View Highlight](https://read.readwise.io/read/01gfvww61zx8f5qxagr01gn6eb))
