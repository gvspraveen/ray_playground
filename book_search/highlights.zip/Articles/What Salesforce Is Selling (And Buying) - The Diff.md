# What Salesforce Is Selling (And Buying) - The Diff

![](https://readwise-assets.s3.amazonaws.com/static/images/article3.5c705a01b476.png)

### Metadata

- Author: Byrne Hobart
- Full Title: What Salesforce Is Selling (And Buying) - The Diff
- Category: #articles


- URL: https://diff.substack.com/p/salesforce-selling

### Highlights

- The IBM model during its peak was:
  Have an excellent sales force.
  Ensure that most revenue is recurring, and ideally expands with usage.
  Develop a comparative advantage in finding new products to feed the voracious sales machine. ([View Highlight](https://instapaper.com/read/1394961440/15791983))
    - **Tags:** #strategy
