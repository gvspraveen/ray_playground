# Fwd: Understanding Flag Carriers

![](https://readwise-assets.s3.amazonaws.com/static/images/article1.be68295a7e40.png)

### Metadata

- Author: instapaper.com
- Full Title: Fwd: Understanding Flag Carriers
- Category: #articles


- URL: https://instapaper.com/read/1369133559

### Highlights

- When the rulers of resource-rich monarchies aren’t worrying about a coup or a revolution, one of their worries is what sort of country their descendants will inherit. And they can do the math: resources eventually run out, and demand shifts, but financial centers can persist forever. The gulf carriers are a way to trade the finite resource of oil for the renewable resource of a concentration of brainy people with capital. ([View Highlight](https://instapaper.com/read/1369133559/14839165))
