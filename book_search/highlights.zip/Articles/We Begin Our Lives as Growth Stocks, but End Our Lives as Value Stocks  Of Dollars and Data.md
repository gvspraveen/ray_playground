# We Begin Our Lives as Growth Stocks, but End Our Lives as Value Stocks – Of Dollars and Data

![](https://readwise-assets.s3.amazonaws.com/static/images/article4.6bc1851654a0.png)

### Metadata

- Author: Nick Maggiulli
- Full Title: We Begin Our Lives as Growth Stocks, but End Our Lives as Value Stocks – Of Dollars and Data
- Category: #articles


- URL: https://ofdollarsanddata.com/we-begin-our-lives-as-growth-stocks-but-end-our-lives-as-value-stocks/

### Highlights

- You may have set your expectations rather high while you were young, only to be let down later. However, as the research suggests, this is completely normal. What’s also normal is lowering your expectations over time, probably too much, to the point where, as you head into old age, pleasant surprises will provide you with additional happiness. We begin our lives as growth stocks, but end our lives as value stocks. ([View Highlight](https://instapaper.com/read/1364531159/14679687))
    - **Tags:** #finance, #progress
