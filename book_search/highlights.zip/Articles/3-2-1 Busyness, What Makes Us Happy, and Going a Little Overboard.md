# 3-2-1: Busyness, What Makes Us Happy, and Going a Little Overboard

![](https://readwise-assets.s3.amazonaws.com/static/images/article0.00998d930354.png)

### Metadata

- Author: James Clear
- Full Title: 3-2-1: Busyness, What Makes Us Happy, and Going a Little Overboard
- Category: #articles

### Highlights

- Every transaction is paid for at least three times. First, with the money you pay. Second, with the time you spend. Third, with the reputation you create through your behavior.
  Being pleasant, reliable, and easy to work with might cost you a little more time. Perhaps even a bit of extra money. But the long-term returns from a great reputation usually outweigh the cost of a single transaction.
  Most of the value in life and in business arises out of good relationships. ([View Highlight](https://read.readwise.io/read/01ggdb6wjtvqb2mp89s8xp6a60))
