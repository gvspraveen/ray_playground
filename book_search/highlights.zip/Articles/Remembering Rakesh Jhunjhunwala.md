# Remembering Rakesh Jhunjhunwala

![](https://www.safalniveshak.com/wp-content/uploads/2022/08/rakesh-jhunjhunwala-new.png)

### Metadata

- Author: Vishal Khandelwal
- Full Title: Remembering Rakesh Jhunjhunwala
- Category: #articles


- URL: https://www.safalniveshak.com/remembering-rakesh-jhunjhunwala/?utm_source=newsletter&utm_medium=email&utm_campaign=remembering_rakesh_jhunjhunwala&utm_term=2022-08-20

### Highlights

- ![](https://1icz9g2sdfe31jz0lglwdu48-wpengine.netdna-ssl.com/wp-content/uploads/2022/08/image-5-2048x1375.png) ([View Highlight](https://read.readwise.io/read/01gay9rpy6x5gtkcf5ct4cqhe6))
