# Zhang Yiming’s Last Speech

![](https://readwise-assets.s3.amazonaws.com/static/images/article3.5c705a01b476.png)

### Metadata

- Author: interconnected.blog
- Full Title: Zhang Yiming’s Last Speech
- Category: #articles


- URL: https://interconnected.blog/zhang-yiming-last-speech/

### Highlights

- Many people in business will say they want to go “all-in” and end the battle at once. I think there is a big problem with teams that just say “all-in”. All-in is sometimes a type of mental laziness. If you have thought very clearly about the strategy, then there is no problem. But my feeling is that in many cases, it's just "I don't want to think about it anymore, let's just do it, let's just go all-in, let's just gamble." ([View Highlight](https://instapaper.com/read/1444281709/17450616))
