# How to Do Long Term · Collaborative Fund

![](https://readwise-assets.s3.amazonaws.com/static/images/article2.74d541386bbf.png)

### Metadata

- Author: collaborativefund.com
- Full Title: How to Do Long Term · Collaborative Fund
- Category: #articles


- URL: http://www.collaborativefund.com/blog/how-to-do-long-term/

### Highlights

- Time is compounding’s magic whose importance can’t be minimized. But the odds of success fall deepest in your favor when you mix a long time horizon with a flexible end date – or an indefinite horizon ([View Highlight](https://instapaper.com/read/1416178739/16532911))
    - **Tags:** #compunding
