# Brain Food: Figuring It Out

![](https://readwise-assets.s3.amazonaws.com/static/images/article4.6bc1851654a0.png)

### Metadata

- Author: FS (Farnam Street)
- Full Title: Brain Food: Figuring It Out
- Category: #articles

### Highlights

- Most people think of demanding and supportive as opposite ends of a spectrum. You can either be tough or you can be nice. But the best leaders don’t choose. They are both highly demanding and highly supportive. They push you to new heights and they also have your back ([View Highlight](https://read.readwise.io/read/01gm2064n1xn5cfnjht8635s26))
    - **Tags:** #leadership
