# Fwd: 3-2-1: On Allowing Yourself to Be Happy and Full, and How Small Errors Compound

![](https://readwise-assets.s3.amazonaws.com/static/images/article3.5c705a01b476.png)

### Metadata

- Author: instapaper.com
- Full Title: Fwd: 3-2-1: On Allowing Yourself to Be Happy and Full, and How Small Errors Compound
- Category: #articles


- URL: https://instapaper.com/read/1394418618

### Highlights

- Books are more likely to change minds than conversations.
  There is too much happening internally during conversation:
  Did that sound stupid?
  What do they think of me?
  Will I lose the friendship over this opinion?
  Books can let you chew on an idea without social ris ([View Highlight](https://instapaper.com/read/1394418618/15775430))
