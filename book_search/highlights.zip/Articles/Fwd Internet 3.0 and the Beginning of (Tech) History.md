# Fwd: Internet 3.0 and the Beginning of (Tech) History

![](https://readwise-assets.s3.amazonaws.com/static/images/article2.74d541386bbf.png)

### Metadata

- Author: instapaper.com
- Full Title: Fwd: Internet 3.0 and the Beginning of (Tech) History
- Category: #articles


- URL: https://instapaper.com/read/1377684208

### Highlights

- Here technology itself will return to the forefront: if the priority for an increasing number of citizens, companies, and countries is to escape centralization, then the answer will not be competing centralized entities, but rather a return to open protocols.1 This is the only way to match and perhaps surpass the R&D advantages enjoyed by centralized tech companies; open technologies can be worked on collectively, and forked individually, gaining both the benefits of scale and inevitability of sovereignty and self-determination. ([View Highlight](https://instapaper.com/read/1377684208/15161072))
    - **Tags:** #strategy
