# Fwd: 30 Days to Better Habits #8: How to Create a Reward That Makes Habits Satisfying

![](https://readwise-assets.s3.amazonaws.com/static/images/article0.00998d930354.png)

### Metadata

- Author: instapaper.com
- Full Title: Fwd: 30 Days to Better Habits #8: How to Create a Reward That Makes Habits Satisfying
- Category: #articles


- URL: https://instapaper.com/read/1478285350

### Highlights

- Incentives can start a habit. Identity sustains a habit.
  That said, it takes time for the evidence to accumulate and a new identity to emerge. Immediate reinforcement helps maintain motivation in the short term while you’re waiting for the long-term rewards to arrive. ([View Highlight](https://instapaper.com/read/1478285350/18616282))
    - **Tags:** #habits
