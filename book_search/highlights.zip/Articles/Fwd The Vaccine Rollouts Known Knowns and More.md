# Fwd: The Vaccine Rollout's Known Knowns and More

![](https://readwise-assets.s3.amazonaws.com/static/images/article4.6bc1851654a0.png)

### Metadata

- Author: instapaper.com
- Full Title: Fwd: The Vaccine Rollout's Known Knowns and More
- Category: #articles


- URL: https://instapaper.com/read/1373810707

### Highlights

- First are things we know (“known knowns”). Then, there are things that we don’t know, but at least we know that we don’t know them (“known unknowns”). And finally are the things that we don’t know that we don’t know (“unknown unknowns”). ([View Highlight](https://instapaper.com/read/1373810707/15005195))
