# Tweets From Preston Pysh

![](https://pbs.twimg.com/profile_images/1408783276081299462/f4Ye5n7-.jpg)

### Metadata

- Author: @PrestonPysh on Twitter
- Full Title: Tweets From Preston Pysh
- Category: #tweets


- URL: https://twitter.com/PrestonPysh

### Highlights

- Some books to learn more:
  Big Debt Crises by @RayDalio
  The Price of Tomorrow by @JeffBooth
  This Time is Different by @carmenmreinhart
  & @krogoff
  The Rise and Fall of Great Powers by Paul Kennedy
  When Money Dies by Adam Fergusson
  The Bitcoin Standard by @saifedean
  Enjoy. ([View Tweet](https://twitter.com/search?q=Some%20books%20to%20learn%20more%3A%20%20Big%20Debt%20Crises%20by%20%40RayDalio%20The%20Price%20of%20Tomorrow%20by%20%40JeffBooth%20This%20Time%20is%20Different%20by%20%40carmenmreinhart%20%20%26%20%40krogoff%20The%20Rise%20and%20Fall%20of%20Great%20Powers%20by%20Paul%20Kennedy%20When%20Money%20Dies%20by%20Adam%20Fergusson%20The%20Bitco%20%28from%3A%40PrestonPysh%29))
- @mattdecelles @RayDalio @Dr_Mario_MD @CaitlinLong_ Ray! You have taught me more about finance than anyone else. Come have an open discussion with @CaitlinLong_ and me. This is a slow release Trojan horse to the financial system. Please take the time to read this thread. https://t.co/dDrnsBqiyy ([View Tweet](https://twitter.com/search?q=%40mattdecelles%20%40RayDalio%20%40Dr_Mario_MD%20%40CaitlinLong_%20Ray%21%20%20You%20have%20taught%20me%20more%20about%20finance%20than%20anyone%20else.%20%20Come%20have%20an%20open%20discussion%20with%20%40CaitlinLong_%20%20and%20me.%20%20This%20is%20a%20slow%20release%20Trojan%20horse%20to%20the%20financial%20system.%20%20Please%20%28from%3A%40PrestonPysh%29))
    - **Tags:** #finance
- But professor...
  When you told me #Bitcoin was a Ponzi scheme you left out the part about the four-year halving cycle and two-week difficulty adjustment...
  How does that work? 
  //Thread Post 1 https://t.co/nJAyyXTVNS ([View Tweet](https://twitter.com/search?q=But%20professor...%20%20When%20you%20told%20me%20%23Bitcoin%20was%20a%20Ponzi%20scheme%20you%20left%20out%20the%20part%20about%20the%20four-year%20halving%20cycle%20and%20two-week%20difficulty%20adjustment...%20%20How%20does%20that%20work%3F%20%20%20%20//Thread%20Post%201%20https%3A//t.co/nJAyyXTVNS%20%28from%3A%40PrestonPysh%29))
    - **Tags:** #finance, #bitcoin
