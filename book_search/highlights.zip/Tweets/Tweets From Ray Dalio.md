# Tweets From Ray Dalio

![](https://pbs.twimg.com/profile_images/1465691046747283461/3ZtnoH5-.jpg)

### Metadata

- Author: @RayDalio on Twitter
- Full Title: Tweets From Ray Dalio
- Category: #tweets


- URL: https://twitter.com/RayDalio

### Highlights

- @Dr_Mario_MD I might be missing something about Bitcoin so I’d love to be corrected. My problems with Bitcoin being an effective currency are simple... (1/5) ([View Tweet](https://twitter.com/search?q=%40Dr_Mario_MD%20I%20might%20be%20missing%20something%20about%20Bitcoin%20so%20I%E2%80%99d%20love%20to%20be%20corrected.%20My%20problems%20with%20Bitcoin%20being%20an%20effective%20currency%20are%20simple...%20%281/5%29%20%28from%3A%40RayDalio%29))
    - **Tags:** #finance
