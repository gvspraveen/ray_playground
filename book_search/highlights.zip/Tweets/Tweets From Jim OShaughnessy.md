# Tweets From Jim O'Shaughnessy

![](https://pbs.twimg.com/profile_images/1609335826395152385/yIJbw2Q9.jpg)

### Metadata

- Author: @jposhaughnessy on Twitter
- Full Title: Tweets From Jim O'Shaughnessy
- Category: #tweets


- URL: https://twitter.com/jposhaughnessy

### Highlights

- “Water is fluid, soft, and yielding. But water will wear away rock, which is rigid and cannot yield. As a rule, whatever is fluid, soft, and yielding will overcome whatever is rigid and hard. This is another paradox: what is soft is strong.”
  ~Lao Tzu, "Tao Te Ching" 
  ![](https://pbs.twimg.com/media/FZCkpNtXEAARH75.jpg) ([View Tweet](https://twitter.com/jposhaughnessy/status/1553923006803726336))
