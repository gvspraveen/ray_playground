# Tweets From Compounding Quality

![](https://pbs.twimg.com/profile_images/1535311789717606403/6eJZ-i2w.jpg)

### Metadata

- Author: @QCompounding on Twitter
- Full Title: Tweets From Compounding Quality
- Category: #tweets


- URL: https://twitter.com/QCompounding

### Highlights

- Compounding can be beautiful: 
  ![](https://pbs.twimg.com/media/FcZTXq-XoAAIL80.jpg) ([View Tweet](https://twitter.com/QCompounding/status/1569075811692396544))
- How to survive bear markets.
  (Source: https://t.co/qrodSC2g1v) 
  ![](https://pbs.twimg.com/media/FcPcHlOXwAAKyon.png) ([View Tweet](https://twitter.com/QCompounding/status/1569416053825753088))
- “I think that's the single best piece of advice: constantly think about how you could be doing things better and questioning yourself.” - Elon Musk 
  ![](https://pbs.twimg.com/media/FcoJ22WWYAISGsB.jpg) ([View Tweet](https://twitter.com/QCompounding/status/1570248791034404868))
