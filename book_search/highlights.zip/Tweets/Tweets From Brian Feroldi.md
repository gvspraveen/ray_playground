# Tweets From Brian Feroldi

![](https://pbs.twimg.com/profile_images/1332873593525571584/btq0XlPB.jpg)

### Metadata

- Author: @BrianFeroldi on Twitter
- Full Title: Tweets From Brian Feroldi
- Category: #tweets


- URL: https://twitter.com/BrianFeroldi

### Highlights

- The P/E ratio is flawed.
  It’s an overused metric that easily deceives investors.
  Here are 8 reasons why the P/E ratio can be INCREDIBLY misleading (and what metrics to use instead): 
  ![](https://pbs.twimg.com/media/FnfgeYaXkAY63TY.jpg) ([View Tweet](https://twitter.com/BrianFeroldi/status/1619012942275686400))
