# Tweets From Chamath Palihapitiya

![](https://pbs.twimg.com/profile_images/1257066367892639744/Yh-QS3we.jpg)

### Metadata

- Author: @chamath on Twitter
- Full Title: Tweets From Chamath Palihapitiya
- Category: #tweets


- URL: https://twitter.com/chamath

### Highlights

- Investing 101: Successful investing is all about behavior and psychology. 
  You can have the best model or analysis in the world but if you panic, you lose. 
  Said differently, everybody has a plan until they get punched in the face.
  Let's begin... ([View Tweet](https://twitter.com/search?q=Investing%20101%3A%20Successful%20investing%20is%20all%20about%20behavior%20and%20psychology.%20%20%20%20You%20can%20have%20the%20best%20model%20or%20analysis%20in%20the%20world%20but%20if%20you%20panic%2C%20you%20lose.%20%20%20%20Said%20differently%2C%20everybody%20has%20a%20plan%20until%20they%20get%20punched%20in%20the%20face.%20%20Let%20%28from%3A%40chamath%29))
