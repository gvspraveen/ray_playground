# Tweets From Brandon Quittem

![](https://pbs.twimg.com/profile_images/1502403738861940736/9J5VuTye.jpg)

### Metadata

- Author: @Bquittem on Twitter
- Full Title: Tweets From Brandon Quittem
- Category: #tweets


- URL: https://twitter.com/Bquittem

### Highlights

- 1/ A quick thread about #Bitcoin and the power of incentives.
  For Bitcoin to reach global dominance, it must inspire a vibrant ecosystem of allies.
  "Show me the incentives, and I'll show you the outcome." 
  Let's go 👇 ([View Tweet](https://twitter.com/search?q=1/%20A%20quick%20thread%20about%20%23Bitcoin%20and%20the%20power%20of%20incentives.%20%20%20For%20Bitcoin%20to%20reach%20global%20dominance%2C%20it%20must%20inspire%20a%20vibrant%20ecosystem%20of%20allies.%20%20%20%22Show%20me%20the%20incentives%2C%20and%20I%27ll%20show%20you%20the%20outcome.%22%20%20%20%20Let%27s%20go%20%F0%9F%91%87%20%28from%3A%40Bquittem%29))
    - **Tags:** #finance
