# Tweets From Prof. Feynman

![](https://pbs.twimg.com/profile_images/1511990640753618949/rZMGSR26.jpg)

### Metadata

- Author: @ProfFeynman on Twitter
- Full Title: Tweets From Prof. Feynman
- Category: #tweets


- URL: https://twitter.com/ProfFeynman

### Highlights

- FIVE Productivity FEYNMAN- strategies: 🧠
  • Stop trying to know-it-all.
  • Don't worry about what others are thinking.
  • Don't think about what you want to be, but what you want to do.
  • Have a sense of humor and talk honestly.
  • Teach others what you know. 
  ![](https://pbs.twimg.com/media/FBeVdIxVEAIH7l6.jpg) ([View Tweet](https://twitter.com/ProfFeynman/status/1447790136431833088))
