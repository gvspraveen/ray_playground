# Tweets From Emily Neumann

![](https://pbs.twimg.com/profile_images/1121448710624415745/zPACWSv4.png)

### Metadata

- Author: @immigrationgirl on Twitter
- Full Title: Tweets From Emily Neumann
- Category: #tweets


- URL: https://twitter.com/immigrationgirl

### Highlights

- Thanks for all your questions! I've tried to answer as many as possible here https://t.co/TuTnckxri9 ([View Tweet](https://twitter.com/search?q=Thanks%20for%20all%20your%20questions%21%20I%27ve%20tried%20to%20answer%20as%20many%20as%20possible%20here%20https%3A//t.co/TuTnckxri9%20%28from%3A%40immigrationgirl%29))
