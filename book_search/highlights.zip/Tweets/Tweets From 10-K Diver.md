# Tweets From 10-K Diver

![](https://pbs.twimg.com/profile_images/1248079061043183616/RUaZCHOi.jpg)

### Metadata

- Author: @10kdiver on Twitter
- Full Title: Tweets From 10-K Diver
- Category: #tweets


- URL: https://twitter.com/10kdiver

### Highlights

- 24/
  Here's a picture that summarizes the main points in this thread: 
  ![](https://pbs.twimg.com/media/FTXbHi7UYAEma8q.jpg) ([View Tweet](https://twitter.com/10kdiver/status/1528374299983110145))
