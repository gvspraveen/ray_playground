# Tweets From Jeff Booth

![](https://pbs.twimg.com/profile_images/1362957991410954241/spiaMAg2.jpg)

### Metadata

- Author: @JeffBooth on Twitter
- Full Title: Tweets From Jeff Booth
- Category: #tweets


- URL: https://twitter.com/JeffBooth

### Highlights

- 1) Don't underestimate the power of a network effect 
  Internet users in 1995 = 16 million 
  Internet users in 2020 ~ 5 Billion
  For those that don't remember the internet in 1995, the use cases were narrow. Most people didn't see what was coming. ([View Tweet](https://twitter.com/search?q=1%29%20Don%27t%20underestimate%20the%20power%20of%20a%20network%20effect%20%20%20Internet%20users%20in%201995%20%3D%2016%20million%20%20Internet%20users%20in%202020%20~%205%20Billion%20%20For%20those%20that%20don%27t%20remember%20the%20internet%20in%201995%2C%20the%20use%20cases%20were%20narrow.%20Most%20people%20didn%27t%20see%20what%20was%20c%20%28from%3A%40JeffBooth%29))
