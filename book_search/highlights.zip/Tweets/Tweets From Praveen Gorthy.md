# Tweets From Praveen Gorthy

![](https://pbs.twimg.com/profile_images/378800000530785519/3e2d2a5645a17150fb1731e811ce93aa.jpeg)

### Metadata

- Author: @praveengorthy on Twitter
- Full Title: Tweets From Praveen Gorthy
- Category: #tweets


- URL: https://twitter.com/praveengorthy

### Highlights

- Rest in peace, Sir! Thank you for your life. Thank you for being there during my darkest days and making my brighter moments even more memorable with your music.
  As we mourn today, yet again you are with us through your music helping us get through with this. #SPB https://t.co/x5UPHVvIaR ([View Tweet](https://twitter.com/search?q=Rest%20in%20peace%2C%20Sir%21%20%20Thank%20you%20for%20your%20life.%20Thank%20you%20for%20being%20there%20during%20my%20darkest%20days%20and%20making%20my%20brighter%20moments%20even%20more%20memorable%20with%20your%20music.%20As%20we%20mourn%20today%2C%20yet%20again%20you%20are%20with%20us%20through%20your%20music%20helping%20us%20ge%20%28from%3A%40praveengorthy%29))
- I cant remember how many times I subconsciously stopped in my stride to capture/grasp this content. The simultaneous depth and breadth of topics covered in this episode is mind boggling. Great work @patrick_oshag and thank you @modestproposal1 for sharing your knowledge. https://t.co/RLqbj7WDXW ([View Tweet](https://twitter.com/search?q=I%20cant%20remember%20how%20many%20times%20I%20subconsciously%20stopped%20in%20my%20stride%20to%20capture/grasp%20this%20content.%20The%20simultaneous%20depth%20and%20breadth%20of%20topics%20covered%20in%20this%20episode%20is%20mind%20boggling.%20Great%20work%20%40patrick_oshag%20and%20thank%20you%20%40modestpropos%20%28from%3A%40praveengorthy%29))
    - **Tags:** #favorite
- "There are nearly endless opportunities to improve each day and finding them largely boils down to being curious.
  People who are better in the end are usually curious in the beginning."
  –@JamesClear ([View Tweet](https://twitter.com/search?q=%22There%20are%20nearly%20endless%20opportunities%20to%20improve%20each%20day%20and%20finding%20them%20largely%20boils%20down%20to%20being%20curious.%20%20People%20who%20are%20better%20in%20the%20end%20are%20usually%20curious%20in%20the%20beginning.%22%20%20%E2%80%93%40JamesClear%20%28from%3A%40praveengorthy%29))
    - **Tags:** #favorite, #progress
