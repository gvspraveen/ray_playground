# To Build Consistently Su...

![](https://pbs.twimg.com/profile_images/1268224036418408449/TFTKnr__.jpg)

### Metadata

- Author: @shreyas on Twitter
- Full Title: To Build Consistently Su...
- Category: #tweets


- URL: https://twitter.com/shreyas/status/1354495293417431041

### Highlights

- To build consistently successful products & teams, modern leaders should remember this:
  1)
  Why > What
  2)
  Listening > Telling
  3)
  Integrity > Skills
  4)
  Clarity of thought > Charisma
  5)
  Ownership > Personal ambition
  6)
  Creativity > IQ
  7)
  High agency > Process loyalty
  👇🏾
    - **Tags:** #leadership, #favorite
- 8)
  Strategy > Plans
  9)
  Examples > Core values
  10)
  Execution > Discussions
  11)
  Kindness > Power
  12)
  Actual progress > Perception
  It isn't that the RHS isn't important.
  It's that leaders should usually prioritize the LHS over RHS, despite temptation for & popularity of RHS.
    - **Tags:** #favorite, #leadership
