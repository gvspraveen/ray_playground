# Tweets From Jana V

![](https://pbs.twimg.com/profile_images/1063603540411613184/Zs6fyAAL.jpg)

### Metadata

- Author: @jvembuna on Twitter
- Full Title: Tweets From Jana V
- Category: #tweets


- URL: https://twitter.com/jvembuna

### Highlights

- Be obsessive about learning in your field. https://t.co/qgREdZ6cGO ([View Tweet](https://twitter.com/search?q=Be%20obsessive%20about%20learning%20in%20your%20field.%20https%3A//t.co/qgREdZ6cGO%20%28from%3A%40jvembuna%29))
- If you believe all dogs are brown, you must not only look for brown dogs, but also look for dogs that aren’t brown. 
  Excellent presentation by Michael A. Covington on How to Write More Clearly, Think More Clearly, and Learn Complex Material More Easily.
  https://t.co/9JZiP9fq23 ([View Tweet](https://twitter.com/jvembuna/status/1386508949650690048))
    - **Tags:** #favorite
