# Tweets From Siva Gurumurthy

![](https://pbs.twimg.com/profile_images/536049942125502465/vMvKgmrP.jpeg)

### Metadata

- Author: @sgurumur on Twitter
- Full Title: Tweets From Siva Gurumurthy
- Category: #tweets


- URL: https://twitter.com/sgurumur

### Highlights

- Some leadership good practices that I observed: have high-touch comms with as many reports, minimize surprises, prioritize their problems that you alone can solve, deeply respect their pov, show respect, show urgency, challenge their thinking, don't easily accept answers. ([View Tweet](https://twitter.com/search?q=Some%20leadership%20good%20practices%20that%20I%20observed%3A%20have%20high-touch%20comms%20with%20as%20many%20reports%2C%20minimize%20surprises%2C%20prioritize%20their%20problems%20that%20you%20alone%20can%20solve%2C%20deeply%20respect%20their%20pov%2C%20show%20respect%2C%20show%20urgency%2C%20challenge%20their%20thinki%20%28from%3A%40sgurumur%29))
    - **Tags:** #leadership
