# Tweets From Shreyas Doshi

![](https://pbs.twimg.com/profile_images/1268224036418408449/TFTKnr__.jpg)

### Metadata

- Author: @shreyas on Twitter
- Full Title: Tweets From Shreyas Doshi
- Category: #tweets


- URL: https://twitter.com/shreyas

### Highlights

- Five concepts with incredibly high ROI:
  1. Talent Stacking
  2. High Agency
  3. Clear Thinking
  4. Deep Work
  5. Transactional Analysis
  Links & References👇🏾 ([View Tweet](https://twitter.com/search?q=Five%20concepts%20with%20incredibly%20high%20ROI%3A%20%201.%20Talent%20Stacking%202.%20High%20Agency%203.%20Clear%20Thinking%204.%20Deep%20Work%205.%20Transactional%20Analysis%20%20Links%20%26%20References%F0%9F%91%87%F0%9F%8F%BE%20%28from%3A%40shreyas%29))
- Product-Market fit is often viewed as a static concept: either you have it or you don’t.
  In my experience, it is better to think of fit as a dynamic state based on your progress towards your vision & know what fit you currently have.
  Check out the 4 Types of Product-Market fit: 
  ![](https://pbs.twimg.com/media/E8xISK6VkAMxdO2.png) ([View Tweet](https://twitter.com/shreyas/status/1426594663671107585))
    - **Note:** save
