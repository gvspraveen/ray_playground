# Tweets From Annanth Aravinthan

![](https://pbs.twimg.com/profile_images/1281071976610779136/m9LAaxSL.jpg)

### Metadata

- Author: @ProtagorasTO on Twitter
- Full Title: Tweets From Annanth Aravinthan
- Category: #tweets


- URL: https://twitter.com/ProtagorasTO

### Highlights

- 2/ In food delivery, a 2 sided mktplace is a traditional aggregator. A sales team adds restos to the platform and marketing acquires users. Restos complete their own delivery, so the aggregator gets to skip all the messy parts and friction in the physical world. ([View Tweet](https://twitter.com/search?q=2/%20In%20food%20delivery%2C%20a%202%20sided%20mktplace%20is%20a%20traditional%20aggregator.%20A%20sales%20team%20adds%20restos%20to%20the%20platform%20and%20marketing%20acquires%20users.%20Restos%20complete%20their%20own%20delivery%2C%20so%20the%20aggregator%20gets%20to%20skip%20all%20the%20messy%20parts%20and%20friction%20%20%28from%3A%40ProtagorasTO%29))
    - **Note:** save the thread
