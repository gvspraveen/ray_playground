# Tweets From Adam Grant

![](https://pbs.twimg.com/profile_images/1427272847643316232/9CeNBJAr.jpg)

### Metadata

- Author: @AdamMGrant on Twitter
- Full Title: Tweets From Adam Grant
- Category: #tweets


- URL: https://twitter.com/AdamMGrant

### Highlights

- Leaders who fail to listen ultimately find themselves surrounded by silence.
  You don't get chosen to take charge unless you give good answers. You won't be able to make change unless you ask good questions.
  Learning depends on making it safe for people to tell you the truth. 
  ![](https://pbs.twimg.com/media/FFc6iCDVQBA6DIH.jpg) ([View Tweet](https://twitter.com/AdamMGrant/status/1465707710679187457))
