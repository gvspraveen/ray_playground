# Tweets From Highscalability

![](https://pbs.twimg.com/profile_images/2597326889/jn0gn42n07wlncznyb1r.jpeg)

### Metadata

- Author: @highscal on Twitter
- Full Title: Tweets From Highscalability
- Category: #tweets


- URL: https://twitter.com/highscal

### Highlights

- Robinhood: Under hyper-growth it's the second-order effects that get you. You can almost always figure out a way to scale something by adding more machines or tuning a database. ([View Tweet](https://twitter.com/search?q=Robinhood%3A%20Under%20hyper-growth%20it%27s%20the%20second-order%20effects%20that%20get%20you.%20You%20can%20almost%20always%20figure%20out%20a%20way%20to%20scale%20something%20by%20adding%20more%20machines%20or%20tuning%20a%20database.%20%28from%3A%40highscal%29))
    - **Tags:** #engineering
