# Tweets From Sino Global Capital

![](https://pbs.twimg.com/profile_images/1429447158655164579/gTQCgV8K.jpg)

### Metadata

- Author: @sinoglobalcap on Twitter
- Full Title: Tweets From Sino Global Capital
- Category: #tweets


- URL: https://twitter.com/sinoglobalcap

### Highlights

- Why we are bullish on Solana.
  Not investment advice. ([View Tweet](https://twitter.com/sinoglobalcap/status/1373662671057383424))
    - **Tags:** #t
