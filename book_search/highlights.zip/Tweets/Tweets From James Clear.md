# Tweets From James Clear

![](https://pbs.twimg.com/profile_images/958932211973152769/FUpkmn4u.jpg)

### Metadata

- Author: @JamesClear on Twitter
- Full Title: Tweets From James Clear
- Category: #tweets


- URL: https://twitter.com/JamesClear

### Highlights

- The world’s shortest leadership philosophy:
  Always know the answer to, “What are we optimizing for?”
  Recruit. Recruit. Recruit.
  Never ask someone to do something you aren’t willing to do yourself.
  Be easy on the person. Be tough on the problem.
  Give all the credit away. ([View Tweet](https://twitter.com/search?q=The%20world%E2%80%99s%20shortest%20leadership%20philosophy%3A%20%20Always%20know%20the%20answer%20to%2C%20%E2%80%9CWhat%20are%20we%20optimizing%20for%3F%E2%80%9D%20%20Recruit.%20Recruit.%20Recruit.%20%20Never%20ask%20someone%20to%20do%20something%20you%20aren%E2%80%99t%20willing%20to%20do%20yourself.%20%20Be%20easy%20on%20the%20person.%20Be%20tough%20on%20the%20%20%28from%3A%40JamesClear%29))
    - **Tags:** #leadership
