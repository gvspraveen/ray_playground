# Tweets From Todd McKinnon

![](https://pbs.twimg.com/profile_images/1408233261503959040/x1NpY_-3.jpg)

### Metadata

- Author: @toddmckinnon on Twitter
- Full Title: Tweets From Todd McKinnon
- Category: #tweets


- URL: https://twitter.com/toddmckinnon

### Highlights

- Before I was a CEO, I made decisions faster. But now, I have the final call so I find myself pondering things more 🤔
  I’m often asked about my decision making process. Here’s a look at what goes into making the most important ones... ([View Tweet](https://twitter.com/search?q=Before%20I%20was%20a%20CEO%2C%20I%20made%20decisions%20faster.%20But%20now%2C%20I%20have%20the%20final%20call%20so%20I%20find%20myself%20pondering%20things%20more%20%F0%9F%A4%94%20%20I%E2%80%99m%20often%20asked%20about%20my%20decision%20making%20process.%20Here%E2%80%99s%20a%20look%20at%20what%20goes%20into%20making%20the%20most%20important%20ones...%20%28from%3A%40toddmckinnon%29))
    - **Note:** Decision making
