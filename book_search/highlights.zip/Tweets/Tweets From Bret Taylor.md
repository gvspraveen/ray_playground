# Tweets From Bret Taylor

![](https://pbs.twimg.com/profile_images/1563227661291270144/-Q5WxHvm.jpg)

### Metadata

- Author: @btaylor on Twitter
- Full Title: Tweets From Bret Taylor
- Category: #tweets


- URL: https://twitter.com/btaylor

### Highlights

- I’m not religious about many things in engineering — seen too many exceptions to “rules” — but firmly believe in having a single repo for all code. Affords so much leverage, and separate repos just optimized for short term. Microservices ≠ Microrepos https://t.co/aRp1fznDIo ([View Tweet](https://twitter.com/search?q=I%E2%80%99m%20not%20religious%20about%20many%20things%20in%20engineering%20%E2%80%94%20seen%20too%20many%20exceptions%20to%20%E2%80%9Crules%E2%80%9D%20%E2%80%94%20but%20firmly%20believe%20in%20having%20a%20single%20repo%20for%20all%20code.%20Affords%20so%20much%20leverage%2C%20and%20separate%20repos%20just%20optimized%20for%20short%20term.%20Microservices%20%E2%89%A0%20%20%28from%3A%40btaylor%29))
    - **Tags:** #favorite
