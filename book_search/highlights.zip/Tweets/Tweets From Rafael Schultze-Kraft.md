# Tweets From Rafael Schultze-Kraft

![](https://pbs.twimg.com/profile_images/1543859266037190658/olP3xBcf.jpg)

### Metadata

- Author: @n3ocortex on Twitter
- Full Title: Tweets From Rafael Schultze-Kraft
- Category: #tweets


- URL: https://twitter.com/n3ocortex

### Highlights

- #Bitcoin is in a supply and liquidity crisis.
  This is extremely bullish! And highly underrated.
  I believe we will see this significantly reflected in Bitcoin's price in the upcoming months.
  Let's take a look at the data.
  A thread 👇👇👇 https://t.co/vx6rJmiloE ([View Tweet](https://twitter.com/search?q=%23Bitcoin%20is%20in%20a%20supply%20and%20liquidity%20crisis.%20%20This%20is%20extremely%20bullish%21%20And%20highly%20underrated.%20%20I%20believe%20we%20will%20see%20this%20significantly%20reflected%20in%20Bitcoin%27s%20price%20in%20the%20upcoming%20months.%20%20Let%27s%20take%20a%20look%20at%20the%20data.%20%20A%20thread%20%F0%9F%91%87%F0%9F%91%87%F0%9F%91%87%20ht%20%28from%3A%40n3ocortex%29))
