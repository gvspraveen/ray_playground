# Tweets From Byrne Hobart

![](https://pbs.twimg.com/profile_images/1404508043702947840/gmf9cyWx.jpg)

### Metadata

- Author: @ByrneHobart on Twitter
- Full Title: Tweets From Byrne Hobart
- Category: #tweets


- URL: https://twitter.com/ByrneHobart

### Highlights

- Today’s free issue is live!
  Surfing the Right S-Curve
  https://t.co/5SJqwdA1CM
  Plus! 
  Google: Benefits and Retention
  Tail Risk on Trial
  Policy Homogeneity
  Procurement
  Density Redistribution
  Crisis Hormesis
  The Other Derivatives Narrative ([View Tweet](https://twitter.com/search?q=Today%E2%80%99s%20free%20issue%20is%20live%21%20%20Surfing%20the%20Right%20S-Curve%20%20https%3A//t.co/5SJqwdA1CM%20%20Plus%21%20%20%20Google%3A%20Benefits%20and%20Retention%20%20Tail%20Risk%20on%20Trial%20%20Policy%20Homogeneity%20%20Procurement%20%20Density%20Redistribution%20%20Crisis%20Hormesis%20%20The%20Other%20Derivatives%20Nar%20%28from%3A%40ByrneHobart%29))
