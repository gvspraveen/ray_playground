# Tweets From Shane Parrish

![](https://pbs.twimg.com/profile_images/1641264347916763137/_xdzak-e.jpg)

### Metadata

- Author: @ShaneAParrish on Twitter
- Full Title: Tweets From Shane Parrish
- Category: #tweets


- URL: https://twitter.com/ShaneAParrish

### Highlights

- Warren Buffett: The Three Things I Look For in a Person https://t.co/DVlsRFODUr ([View Tweet](https://twitter.com/search?q=Warren%20Buffett%3A%20The%20Three%20Things%20I%20Look%20For%20in%20a%20Person%20https%3A//t.co/DVlsRFODUr%20%28from%3A%40ShaneAParrish%29))
- There is a concept known as probabilistic thinking. 
  Here is how you can use it in work and life. 
  👇👇👇 ([View Tweet](https://twitter.com/search?q=There%20is%20a%20concept%20known%20as%20probabilistic%20thinking.%20%20%20Here%20is%20how%20you%20can%20use%20it%20in%20work%20and%20life.%20%20%20%F0%9F%91%87%F0%9F%91%87%F0%9F%91%87%20%28from%3A%40ShaneAParrish%29))
- Outcome over ego.
  Replace the need to be proven right with the desire to achieve the best outcome. ([View Tweet](https://twitter.com/search?q=Outcome%20over%20ego.%20%20Replace%20the%20need%20to%20be%20proven%20right%20with%20the%20desire%20to%20achieve%20the%20best%20outcome.%20%28from%3A%40ShaneAParrish%29))
