# Tweets From Radhika Gupta

![](https://pbs.twimg.com/profile_images/1624001595699789824/PUjE_-Bh.jpg)

### Metadata

- Author: @iRadhikaGupta on Twitter
- Full Title: Tweets From Radhika Gupta
- Category: #tweets


- URL: https://twitter.com/iRadhikaGupta

### Highlights

- Break decisions into one way doors (irreversible ones) and two way doors (reversible ones).
  Be slow and consensus driven with one way doors, and quick and individual driven with two way doors. Most firms think every decision is a one way door and end up being slow.
  -Jeff Bezos ([View Tweet](https://twitter.com/search?q=Break%20decisions%20into%20one%20way%20doors%20%28irreversible%20ones%29%20and%20two%20way%20doors%20%28reversible%20ones%29.%20%20Be%20slow%20and%20consensus%20driven%20with%20one%20way%20doors%2C%20and%20quick%20and%20individual%20driven%20with%20two%20way%20doors.%20%20Most%20firms%20think%20every%20decision%20is%20a%20one%20way%20%20%28from%3A%40iRadhikaGupta%29))
    - **Tags:** #favorite, #decision
