# Tweets From Ankit Pansari

![](https://pbs.twimg.com/profile_images/1474645695554461696/jzErfRvN.jpg)

### Metadata

- Author: @ankitpansari_ on Twitter
- Full Title: Tweets From Ankit Pansari
- Category: #tweets


- URL: https://twitter.com/ankitpansari_

### Highlights

- Twilio, with a market cap of $45B, is going to acquire Segment for $3.2 B. 
  Q: Why are these companies of such high value? 
  A: We need to first understand the modern software development stack and two essential concepts:
  1. Abstraction 
  2. Undifferentiated Heavy Lifting. 
  🧵 https://t.co/9qnyLfU23W ([View Tweet](https://twitter.com/search?q=Twilio%2C%20with%20a%20market%20cap%20of%20%2445B%2C%20is%20going%20to%20acquire%20Segment%20for%20%243.2%20B.%20%20%20Q%3A%20Why%20are%20these%20companies%20of%20such%20high%20value%3F%20%20%20A%3A%20%20We%20need%20to%20first%20understand%20the%20modern%20software%20development%20stack%20and%20two%20essential%20concepts%3A%20%201.%20Abstraction%20%20%28from%3A%40ankitpansari_%29))
