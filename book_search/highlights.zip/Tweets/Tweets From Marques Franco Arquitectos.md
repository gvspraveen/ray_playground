# Tweets From Marques Franco Arquitectos

![](https://pbs.twimg.com/profile_images/1516437915353681921/aI58kuV6.jpg)

### Metadata

- Author: @MarquesFrancoA1 on Twitter
- Full Title: Tweets From Marques Franco Arquitectos
- Category: #tweets


- URL: https://twitter.com/MarquesFrancoA1

### Highlights

- The master cloner masterplan. How can you lose money following this? @MohnishPabrai @GSpier @williamgreen72 @TomInvesting @afterinvestor @bkaellner @cloneinvestor 
  ![](https://pbs.twimg.com/media/FIB4i4JXwAIliLW.jpg) ([View Tweet](https://twitter.com/MarquesFrancoA1/status/1477313224638873600))
