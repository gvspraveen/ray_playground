# Tweets From Tim Urban

![](https://pbs.twimg.com/profile_images/378800000096549990/2b5b8a614e16b1527ebb75e1a7266d85.jpeg)

### Metadata

- Author: @waitbutwhy on Twitter
- Full Title: Tweets From Tim Urban
- Category: #tweets


- URL: https://twitter.com/waitbutwhy

### Highlights

- Go hug someone 
  ![](https://pbs.twimg.com/media/E_cbRymWQAAKPi3.png) ([View Tweet](https://twitter.com/waitbutwhy/status/1438648642454315010))
    - **Tags:** #favorite
