# Dare to Lead

![](https://images-na.ssl-images-amazon.com/images/I/41b8%2BTEXKAL._SL200_.jpg)

### Metadata

- Author: Brené Brown
- Full Title: Dare to Lead
- Category: #books

### Highlights

- We know that the way to move information from your head to your heart is through your hands. ([Location 214](https://readwise.io/to_kindle?action=open&asin=B07CWGFPS7&location=214))
