# How to Take Smart Notes

![](https://images-na.ssl-images-amazon.com/images/I/41iVa0x-P-L._SL200_.jpg)

### Metadata

- Author: Sönke Ahrens
- Full Title: How to Take Smart Notes
- Category: #books

### Highlights

- Studies on highly successful people have proven again and again that success is not the result of strong willpower and the ability to overcome resistance, but rather the result of smart working environments that avoid resistance in the first place ([Location 381](https://readwise.io/to_kindle?action=open&asin=B06WVYW33Y&location=381))
    - **Tags:** #habits
