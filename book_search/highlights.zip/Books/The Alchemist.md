# The Alchemist

![](https://images-na.ssl-images-amazon.com/images/I/51Z0nLAfLmL._SL200_.jpg)

### Metadata

- Author: Paulo Coelho
- Full Title: The Alchemist
- Category: #books

### Highlights

- The secret is here in the present. If you pay attention to the present, you can improve upon it. And, if you improve on the present, what comes later will also be better. Forget about the future, and live each day according to the teachings, confident that God loves his children. Each day, in itself, brings with it an eternity.” ([Location 1280](https://readwise.io/to_kindle?action=open&asin=B00U6SFUSS&location=1280))
