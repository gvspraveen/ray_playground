# The Sketchbook of Wisdom

![](https://readwise-assets.s3.amazonaws.com/static/images/default-book-icon-0.c6917d331b03.png)

### Metadata

- Author: Safal niveshak
- Full Title: The Sketchbook of Wisdom
- Category: #books

### Highlights

- In a thought-provoking note, English comedian and writer Stephen Fry quoted the Irish poet and playwright Oscar Wilde as saying that "if Jou know what you want to be, then you inevitably become it. That is your punishment. But if you never know, then you can be anything.
  There is a truth to that. We are not nouns, we are verbs. I am not a thing - an actor, a writer - I am a person who does things - I write, I act - and I never know what I am going to do next. I think you can be imprisoned if you think of yourself as a noun.”
    - **Tags:** #lifetyle
