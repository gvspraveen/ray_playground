# Outliers

![](https://images-na.ssl-images-amazon.com/images/I/41kXEQoH9rL._SL200_.jpg)

### Metadata

- Author: Malcolm Gladwell
- Full Title: Outliers
- Category: #books

### Highlights

- argue that there is something profoundly wrong with the way we make sense of success. ([Location 151](https://readwise.io/to_kindle?action=open&asin=B001ANYDAO&location=151))
- “No one who can rise before dawn three hundred sixty days a year fails to make his family rich.” ([Location 2688](https://readwise.io/to_kindle?action=open&asin=B001ANYDAO&location=2688))
