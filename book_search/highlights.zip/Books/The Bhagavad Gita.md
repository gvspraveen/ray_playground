# The Bhagavad Gita

![](https://images-na.ssl-images-amazon.com/images/I/41amluFyMfL._SL200_.jpg)

### Metadata

- Author: Eknath Easwaran Ed.
- Full Title: The Bhagavad Gita
- Category: #books

### Highlights

- “Yoga is evenness of mind”: detachment from the dualities of pain and pleasure, success and failure. Therefore “yoga is skill in action,” because this kind of detachment is required if one is to act in freedom, rather than merely react to events compelled by conditioning. ([Location 801](https://readwise.io/to_kindle?action=open&asin=B004DI7R5G&location=801))
- What power binds us to our selfish ways? Even if we wish to act rightly, so often we do the wrong thing. What power moves us? Krishna replies that anger and selfish desire are our greatest enemies. They are the destructive powers that can compel us to wander away from our purpose, to end up in self-delusion and despair. ([Location 978](https://readwise.io/to_kindle?action=open&asin=B004DI7R5G&location=978))
