# Troublemakers

![](https://images-na.ssl-images-amazon.com/images/I/51SK5uvmvKL._SL200_.jpg)

### Metadata

- Author: Leslie Berlin
- Full Title: Troublemakers
- Category: #books

### Highlights

- “You can’t really understand what is going on now unless you understand what came before.” ([Location 88](https://readwise.io/to_kindle?action=open&asin=B06ZZ1YDTX&location=88))
