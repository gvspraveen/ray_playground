# Story 10x

![](https://images-na.ssl-images-amazon.com/images/I/41azilDWK4L._SL200_.jpg)

### Metadata

- Author: Michael Margolis
- Full Title: Story 10x
- Category: #books

### Highlights

- Story Narrative Story > Narrative Set-up Context Present the future in aspirational terms—how change leads to opportunity Conflict Emotion Build empathy, describing the gap between desire and dilemma Resolution Evidence Provide supporting data that legitimizes the promise of your big idea ([Location 348](https://readwise.io/to_kindle?action=open&asin=B07VCMB7GR&location=348))
- You have maybe five minutes to get 90 percent of the room on your side. While you could begin with something provocative and challenging, as we discussed earlier, this is likely to put people on the defensive and leave a lot of broken glass. People are increasingly experiencing information overload and attention deficit. If you start with the data, they will likely question the numbers or struggle to empathize, identify, or relate. You have just a few precious minutes to capture your audience’s attention and establish relevance. How can you convince them to care about what your message? Remind them of what’s possible. Start with YES! Capture the imagination, get people leaning in, excited, and intrigued. To quote Victor Hugo, “There is nothing like a dream to create the future.” Be a messenger from the future. Bring the good news. Share your excitement about what you see. Show your audience how change equals possibility. ([Location 1225](https://readwise.io/to_kindle?action=open&asin=B07VCMB7GR&location=1225))
    - **Tags:** #leadership
    - **Note:** People feel motivated for a positive future than a fear or doomsday narrative
- To succeed in your high-stakes presentation, you have to show your audience the context for change. Help them embrace the inevitability of the future that you’re describing and the opportunities that come with being out in front of the change. Do this well, and your vision is undeniable. ([Location 1390](https://readwise.io/to_kindle?action=open&asin=B07VCMB7GR&location=1390))
    - **Tags:** #leadership
