# A Few Lessons From Sherlock Holmes

![](https://images-na.ssl-images-amazon.com/images/I/31voXsdGgFL._SL200_.jpg)

### Metadata

- Author: Peter Bevelin
- Full Title: A Few Lessons From Sherlock Holmes
- Category: #books

### Highlights

- Considering many ideas over a wide range of disciplines give us perspective and help us consider the big picture or many aspects of an issue ([Location 92](https://readwise.io/to_kindle?action=open&asin=B00DMGK97I&location=92))
