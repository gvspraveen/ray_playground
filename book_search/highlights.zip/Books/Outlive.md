# Outlive

![](https://m.media-amazon.com/images/I/71ZcOX2ss9L._SY160.jpg)

### Metadata

- Author: Peter  Attia MD
- Full Title: Outlive
- Category: #books

### Highlights

- “metabolic syndrome” (or MetSyn), and it is defined in terms of the following five criteria: high blood pressure (>130/85) high triglycerides (>150 mg/dL) low HDL cholesterol (<40 mg/dL in men or <50 mg/dL in women) central adiposity (waist circumference >40 inches in men or >35 in women) elevated fasting glucose (>110 mg/dL) ([Location 1490](https://readwise.io/to_kindle?action=open&asin=B0B1BTJLJN&location=1490))
    - **Tags:** #health
- Insulin resistance is a term that we hear a lot, but what does it really mean? Technically, it means that cells, initially muscle cells, have stopped listening to insulin’s signals, but another way to visualize it is to imagine the cell as a balloon being blown up with air. Eventually, the balloon expands to the point where it gets more difficult to force more air inside. You have to blow harder and harder. This is where insulin comes in, to help facilitate the process of blowing air into the balloon. The pancreas begins to secrete even more insulin, to try to remove excess glucose from the bloodstream and cram it into cells. For the time being it works, and blood glucose levels remain normal, but eventually you reach a limit where the “balloon” (cells) cannot accept any more “air” (glucose). This is when the trouble shows up on a standard blood test, as fasting blood glucose begins to rise. This means you have high insulin levels and high blood glucose, and your cells are shutting the gates to glucose entry. If things continue in this way, then the pancreas becomes fatigued and less able to mount an insulin response. This is made worse by, you guessed it, the fat now residing in the pancreas itself. ([Location 1592](https://readwise.io/to_kindle?action=open&asin=B0B1BTJLJN&location=1592))
    - **Tags:** #health
- Whatever form it takes, fructose does not pose a problem when consumed the way that our ancestors did, before sugar became a ubiquitous commodity: mostly in the form of actual fruit. It is very difficult to get fat from eating too many apples, for example, because the fructose in the apple enters our system relatively slowly, mixed with fiber and water, and our gut and our metabolism can handle it normally. ([Location 1676](https://readwise.io/to_kindle?action=open&asin=B0B1BTJLJN&location=1676))
    - **Tags:** #health
- The mechanisms are a bit complicated, but the bottom line is that even though it is rich in energy, fructose basically tricks our metabolism into thinking that we are depleting energy—and need to take in still more food and store more energy as fat. ([Location 1691](https://readwise.io/to_kindle?action=open&asin=B0B1BTJLJN&location=1691))
