# One Up on Wall Street

![](https://images-na.ssl-images-amazon.com/images/I/51Pft%2B2gbaL._SL200_.jpg)

### Metadata

- Author: Peter Lynch
- Full Title: One Up on Wall Street
- Category: #books

### Highlights

- Only invest what you could afford to lose without that loss having any effect on your daily life in the foreseeable future. ([Location 1204](https://readwise.io/to_kindle?action=open&asin=B006YDFYW6&location=1204))
- Although it’s easy to forget sometimes, a share of stock is not a lottery ticket. It’s part ownership of a business. ([Location 2500](https://readwise.io/to_kindle?action=open&asin=B006YDFYW6&location=2500))
    - **Tags:** #favorite
