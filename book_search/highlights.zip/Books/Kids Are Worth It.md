# Kids Are Worth It!

![](https://images-na.ssl-images-amazon.com/images/I/41%2Bk0CkzfPL._SL200_.jpg)

### Metadata

- Author: Barbara Coloroso
- Full Title: Kids Are Worth It!
- Category: #books

### Highlights

- think. They are encouraged to listen to their own intuition, to be spontaneous, to be creative in thoughts and actions, ([Location 722](https://readwise.io/to_kindle?action=open&asin=B0034EJL40&location=722))
    - **Tags:** #pink
