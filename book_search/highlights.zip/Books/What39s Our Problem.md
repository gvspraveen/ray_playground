# What&#39;s Our Problem?

![](https://m.media-amazon.com/images/I/61V7z7DbVKL._SY160.jpg)

### Metadata

- Author: Tim Urban
- Full Title: What&#39;s Our Problem?
- Category: #books

### Highlights

- Unlike technological growth, wisdom seems to oscillate up and down, leading societies to repeat age-old mistakes. ([Location 103](https://readwise.io/to_kindle?action=open&asin=B0BTJCTR58&location=103))
- But Echo Chambers equate a person’s ideas with their identity, so respecting a person and respecting their ideas are one and the same. Disagreeing with someone in an Echo Chamber is seen not as intellectual exploration but as rudeness, making an argument about ideas indistinguishable from a fight. ([Location 520](https://readwise.io/to_kindle?action=open&asin=B0BTJCTR58&location=520))
