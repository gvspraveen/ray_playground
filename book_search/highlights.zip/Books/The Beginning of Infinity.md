# The Beginning of Infinity

![](https://images-na.ssl-images-amazon.com/images/I/51ZFmRLeKLL._SL200_.jpg)

### Metadata

- Author: David Deutsch
- Full Title: The Beginning of Infinity
- Category: #books

### Highlights

- As the physicist Stephen Hawking put it, humans are ‘just a chemical scum on the surface of a typical planet that’s in orbit round a typical star on the outskirts of a typical galaxy’. ([Location 793](https://readwise.io/to_kindle?action=open&asin=B005DXR5ZC&location=793))
