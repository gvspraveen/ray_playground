# The Back of the Napkin

![](https://images-na.ssl-images-amazon.com/images/I/61lCAdzXcOL._SL200_.jpg)

### Metadata

- Author: Dan Roam
- Full Title: The Back of the Napkin
- Category: #books

### Highlights

- problem can be made clearer with a picture, and any picture can be created using the same set of tools and rules. ([Location 306](https://readwise.io/to_kindle?action=open&asin=B005N1OUSE&location=306))
- Understanding visual thinking as a complete process means that the starting point isn’t learning to draw better, it’s learning to look better. That’s why the process is valuable: It puts looking—something we’re all innately good at—back at the front of the line. ([Location 721](https://readwise.io/to_kindle?action=open&asin=B005N1OUSE&location=721))
- Seeing is the flip side of looking: Looking is the open process of collecting visual information, seeing is the narrowing process of putting the visual pieces together in order to make sense of them. Looking is collecting; seeing is selecting and identifying patterns. And really good seeing is even more than just pattern recognition; good seeing is problem recognition. ([Location 1018](https://readwise.io/to_kindle?action=open&asin=B005N1OUSE&location=1018))
