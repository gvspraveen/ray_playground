# Draft No. 4

![](https://images-na.ssl-images-amazon.com/images/I/319KqMynyBL._SL200_.jpg)

### Metadata

- Author: John McPhee
- Full Title: Draft No. 4
- Category: #books

### Highlights

- “You can build a strong, sound, and artful structure. You can build a structure in such a way that it causes people to want to keep turning pages. A compelling structure in nonfiction can have an attracting effect analogous to a story line in fiction.” ([Location 259](https://readwise.io/to_kindle?action=open&asin=B06X18NHC1&location=259))
    - **Tags:** #writing
