# The Inner Game of Tennis

![](https://images-na.ssl-images-amazon.com/images/I/41UsNqMkiAL._SL200_.jpg)

### Metadata

- Author: W. Timothy Gallwey
- Full Title: The Inner Game of Tennis
- Category: #books

### Highlights

- backhand corner of one of the service courts. Then figure out how you should swing your racket in order to hit the can. Think about how high to toss the ball, about the proper ([Location 689](https://readwise.io/to_kindle?action=open&asin=B003T0G9E4&location=689))
- It is not helpful to condemn our present behavior patterns—in this case our present imperfect strokes—as “bad”; it is helpful to see what function these habits are serving, so that if we learn a better way to achieve the same end, we can do so. ([Location 1087](https://readwise.io/to_kindle?action=open&asin=B003T0G9E4&location=1087))
- THE INNER GAME WAY OF LEARNING STEP 1   Observe Existing Behavior Nonjudgmentally Examples: The last three of my backhands landed long, by about two feet. My racket seems to be hesitating, instead of following through all the way. Maybe I should observe the level of my back-swing … It’s well above my waist… There, that shot got hit with more pace, yet it stayed in. (The above is delivered in an interested, somewhat detached tone.) STEP 2   Picture Desired Outcome No commands are used. Self 2 is asked to perform in the desired way to achieve the desired results. Self 2 is shown by use of visual image and felt action any element of stroke desired. If you wish the ball to go to the crosscourt corner, you simply imagine the necessary path of the ball to the target. Do not try to correct for past errors. STEP 3   Let It Happen! Trust Self 2 Having requested your body to perform a certain action, give it the freedom to do it. The body is trusted, without the conscious control of mind. The serve seems to serve itself. Effort is initiated by Self 2, but there is no trying by Self 1. Letting it happen doesn’t mean going limp; it means letting Self 2 use only the muscles necessary for the job. Nothing is forced. Continue the process. Be willing to allow Self 2 to make changes within changes, until a natural groove is formed. STEP 4   Nonjudgmental, Calm Observation of the Results Leading to Continuing Observation and Learning Though the player knows his goal, he is not emotionally involved in achieving it and is therefore able to watch the results calmly and experience the process. By ([Location 1191](https://readwise.io/to_kindle?action=open&asin=B003T0G9E4&location=1191))
    - **Tags:** #learning
- When the mind is fastened to the rhythm of breathing, it tends to become absorbed and calm. Whether on or off the court, I know of no better way to begin to deal with anxiety than to place the mind on one’s breathing process. Anxiety is fear about what may happen in the future, and it occurs only when the mind is imagining what the future may bring. But when your attention is on the here and now, the actions which need to be done in the present have their best chance of being successfully accomplished, and as a result the future will become the best possible present. ([Location 1461](https://readwise.io/to_kindle?action=open&asin=B003T0G9E4&location=1461))
- Winning is overcoming obstacles to reach a goal, but the value in winning is only as great as the value of the goal reached. Reaching the goal itself may not be as valuable as the experience that can come in making a supreme effort to overcome the obstacles involved. The process can be more rewarding than the victory itself. ([Location 1791](https://readwise.io/to_kindle?action=open&asin=B003T0G9E4&location=1791))
    - **Tags:** #habits
