# Shoe Dog

![](https://images-na.ssl-images-amazon.com/images/I/41k%2BWVPLwZL._SL200_.jpg)

### Metadata

- Author: Phil Knight
- Full Title: Shoe Dog
- Category: #books

### Highlights

- I was a linear thinker, and according to Zen linear thinking is nothing but a delusion, one of the many that keep us unhappy. Reality is nonlinear, Zen says. No future, no past. All is now. ([Location 302](https://readwise.io/to_kindle?action=open&asin=B0176M1A44&location=302))
- People reflexively assume that competition is always a good thing, that it always brings out the best in people, but that’s only true of people who can forget the competition. The art of competing, I’d learned from track, was the art of forgetting, and I now reminded myself of that fact. You must forget your limits. You must forget your doubts, your pain, your past. ([Location 873](https://readwise.io/to_kindle?action=open&asin=B0176M1A44&location=873))
