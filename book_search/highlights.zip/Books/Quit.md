# Quit

![](https://m.media-amazon.com/images/I/71A7vbj+NUL._SY160.jpg)

### Metadata

- Author: Annie Duke
- Full Title: Quit
- Category: #books

### Highlights

- When we are in the losses, we are not only more likely to stick to a losing course of action, but also to double down. This tendency is called escalation of commitment. Escalation of commitment is robust and universal, occurring in individuals, organizations, and governmental entities. All of us tend to get stuck in courses of action once started, especially in the face of bad news. Escalation of commitment doesn’t just occur in high-stakes situations. It also happens when the stakes are low, demonstrating the pervasiveness of the error. ([Location 1482](https://readwise.io/to_kindle?action=open&asin=B09PTLY4BL&location=1482))
- Be picky about what you stick to. Persevere in the things that matter, that bring you happiness, and that move you toward your goals. Quit everything else, to free up those resources so you can pursue your goals and stop sticking to things that slow you down. ([Location 2829](https://readwise.io/to_kindle?action=open&asin=B09PTLY4BL&location=2829))
