# The Metaverse

![](https://m.media-amazon.com/images/I/91ktfa+F-TL._SY160.jpg)

### Metadata

- Author: Matthew Ball
- Full Title: The Metaverse
- Category: #books

### Highlights

- “A massively scaled and interoperable network of real-time rendered 3D virtual worlds that can be experienced synchronously and persistently by an effectively unlimited number of users with an individual sense of presence, and with continuity of data, such as identity, history, entitlements, objects, communications, and payments.” ([Location 585](https://readwise.io/to_kindle?action=open&asin=B09KMWYHX8&location=585))
