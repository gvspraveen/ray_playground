# Clean Code

![](https://images-na.ssl-images-amazon.com/images/I/51d1qVhmAmL._SL200_.jpg)

### Metadata

- Author: Robert C. Martin
- Full Title: Clean Code
- Category: #books

### Highlights

- Bjarne Stroustrup, inventor of C++ and author of The C++ Programming Language I like my code to be elegant and efficient. The logic should be straightforward to make it hard for bugs to hide, the dependencies minimal to ease maintenance, error handling complete according to an articulated strategy, and performance close to optimal so as not to tempt people to make the code messy with unprincipled optimizations. Clean code does one thing well. ([Location 603](https://readwise.io/to_kindle?action=open&asin=B001GSTOAM&location=603))
    - **Tags:** #engineering
