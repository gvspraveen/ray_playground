# The Essays of Warren Buffett

![](https://images-na.ssl-images-amazon.com/images/I/51iyTrpP9NL._SL200_.jpg)

### Metadata

- Author: Lawrence A. Cunningham, Warren E. Buffett
- Full Title: The Essays of Warren Buffett
- Category: #books

### Highlights

- Time is the friend of the wonderful business, the enemy of the mediocre. ([Location 2400](https://readwise.io/to_kindle?action=open&asin=B01J2SLA5O&location=2400))
