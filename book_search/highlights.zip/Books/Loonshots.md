# Loonshots

![](https://images-na.ssl-images-amazon.com/images/I/41xeO-IKMUL._SL200_.jpg)

### Metadata

- Author: Safi Bahcall
- Full Title: Loonshots
- Category: #books

### Highlights

- Separate your artists and soldiers People responsible for developing high-risk, early-stage ideas (call them “artists”) need to be sheltered from the “soldiers” responsible for the already-successful, steady-growth part of an organization. ([Location 631](https://readwise.io/to_kindle?action=open&asin=B07D2BKVQR&location=631))
- You can analyze why an investment went south. The company’s balance sheet was too weak, for example. That’s outcome mindset. But you will gain much more from analyzing the process by which you arrived at the decision to invest. What’s on your diligence list? How do you go through that list? Did something distract you or cause you to overlook or ignore that item on the list? What should you change about what’s on your list or how you conduct your analyses or how you draw your conclusions—the process behind the decision to invest—to ensure that mistake won’t happen again? That’s system mindset. ([Location 2383](https://readwise.io/to_kindle?action=open&asin=B07D2BKVQR&location=2383))
    - **Tags:** #decision
    - **Note:** outcome mindset vs system mindset
- Teams with a system mindset, level 2, probe the decision-making process behind a failure. How did we arrive at that decision? Should a different mix of people be involved, or involved in a different way? Should we change how we analyze opportunities before making similar decisions in the future? How do the incentives we have in place affect our decision-making? Should those be changed? System mindset means carefully examining the quality of decisions, not just the quality of outcomes. A failed outcome, for example, does not necessarily mean the decision or decision process behind it was bad. There are good decisions with bad outcomes. Those are intelligent risks, well taken, that didn’t play out. ([Location 2396](https://readwise.io/to_kindle?action=open&asin=B07D2BKVQR&location=2396))
    - **Tags:** #leadership
- For a loonshot nursery to flourish—inside either a company or an industry—three conditions must be met: 1. Phase separation: separate loonshot and franchise groups 2. Dynamic equilibrium: seamless exchange between the two groups 3. Critical mass: a loonshot group large enough to ignite ([Location 3963](https://readwise.io/to_kindle?action=open&asin=B07D2BKVQR&location=3963))
