# Pragmatic Capitalism

![](https://m.media-amazon.com/images/I/71TucfIzePL._SY160.jpg)

### Metadata

- Author: Cullen Roche
- Full Title: Pragmatic Capitalism
- Category: #books

### Highlights

- For an economic system the equivalent of sitting on the couch and eating pizza is a system in which the economic agents are unable to find productive uses for the flow of goods and services. In this scenario living standards stagnate, the flow stagnates, and the system deteriorates. ([Location 315](https://readwise.io/to_kindle?action=open&asin=B0B4V1KHVD&location=315))
    - **Tags:** #favorite
