# "Surely You're Joking, Mr. Feynman!"

![](https://images-na.ssl-images-amazon.com/images/I/51PXthXhbiL._SL200_.jpg)

### Metadata

- Author: Richard P. Feynman, Ralph Leighton, Edward Hutchings, and Albert R. Hibbs
- Full Title: "Surely You're Joking, Mr. Feynman!"
- Category: #books

### Highlights

- It was a brilliant idea: You have no responsibility to live up to what other people think you ought to accomplish. I have no responsibility to be like they expect me to be. It’s their mistake, not my failing. ([Location 2539](https://readwise.io/to_kindle?action=open&asin=B003V1WXKU&location=2539))
    - **Tags:** #favorite
- opinions. Of course, you only live one life, and you make all your mistakes, and learn what not to do, and that’s the end of you. ([Location 3822](https://readwise.io/to_kindle?action=open&asin=B003V1WXKU&location=3822))
- The first principle is that you must not fool yourself—and you are the easiest person to fool. So you have to be very careful about that. After you’ve not fooled yourself, it’s easy not to fool other scientists. You just have to be honest in a conventional way after that. ([Location 5154](https://readwise.io/to_kindle?action=open&asin=B003V1WXKU&location=5154))
